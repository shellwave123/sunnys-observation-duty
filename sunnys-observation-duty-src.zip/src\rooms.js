// Five CCTV stations: the office you stand in (CAM 01) plus four remote
// rooms parked far outside the playable volume (never seen by the player).
import * as THREE from 'three';
import { hardwoodTexture, carpetTexture, contactShadow, tileTexture, concreteTexture, curtainTexture, paintingTexture } from './textures.js';

const OPT = { fog: false };

/**
 * Prop material. The small emissive lift keeps furniture legible on a
 * security feed even when the key light is behind it — CCTV footage with
 * pure-black props is unreadable, and the player has to spot a subject
 * standing among them.
 */
function mat(color, opts = {}) {
  return new THREE.MeshStandardMaterial({
    color,
    roughness: 0.9,
    metalness: 0.05,
    emissive: color,
    emissiveIntensity: 0.17,
    ...OPT,
    ...opts,
  });
}
function glowMat(color, intensity = 1.1) {
  return new THREE.MeshStandardMaterial({ color: 0x080808, emissive: color, emissiveIntensity: intensity, roughness: 0.6, ...OPT });
}
function box(w, h, d, m) { return new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m); }
function plane(w, h, m) { return new THREE.Mesh(new THREE.PlaneGeometry(w, h), m); }
function cyl(rt, rb, h, m, seg = 16) { return new THREE.Mesh(new THREE.CylinderGeometry(rt, rb, h, seg), m); }

/**
 * Architecture and dressing should appear on CCTV without becoming invisible
 * report blockers. Occlusion tests are meant for furniture and the subject,
 * not baseboards, rugs, curtains, or wall plates.
 */
function noAim(obj) {
  obj.traverse((o) => { if (o.isMesh) o.raycast = () => {}; });
  return obj;
}
function trim(color = 0xe6dcc6) {
  return mat(color, { roughness: 0.55 });
}
function fabric(color, opts = {}) {
  return mat(color, { roughness: 0.95, ...opts });
}
function wood(color = 0x6b4a2b) {
  return mat(color, { roughness: 0.58, metalness: 0.03 });
}

/** Baseboards, crown, and a runner-friendly floor edge for a finished home. */
function homeShell(w, h, d, floorMat, wallColor, lift = 0.40) {
  const g = shell(w, h, d, 0xffffff, wallColor, lift);
  // Replace the shell's plain floor material with a real home surface.
  g.children[0].material = new THREE.MeshStandardMaterial({
    map: floorMat,
    roughness: 0.72,
    metalness: 0.03,
    emissive: 0xffffff,
    emissiveMap: floorMat,
    emissiveIntensity: lift,
    ...OPT,
  });
  const t = trim();
  const baseLong = box(w, 0.12, 0.05, t);
  noAim(baseLong); put(g, baseLong, 0, 0.06, -d / 2 + 0.026);
  const baseLong2 = box(w, 0.12, 0.05, t);
  noAim(baseLong2); put(g, baseLong2, 0, 0.06, d / 2 - 0.026);
  const baseSide = box(0.05, 0.12, d, t);
  noAim(baseSide); put(g, baseSide, -w / 2 + 0.026, 0.06, 0);
  const baseSide2 = box(0.05, 0.12, d, t);
  noAim(baseSide2); put(g, baseSide2, w / 2 - 0.026, 0.06, 0);
  const crown = box(w, 0.09, 0.06, t);
  noAim(crown); put(g, crown, 0, h - 0.045, -d / 2 + 0.031);
  const crown2 = box(w, 0.09, 0.06, t);
  noAim(crown2); put(g, crown2, 0, h - 0.045, d / 2 - 0.031);
  return g;
}

/** Framed residential art that stays high enough to avoid gameplay sightlines. */
function wallArt(parent, x, y, z, ry, w = 0.72, h = 0.56, art = 0x365a73) {
  const g = new THREE.Group();
  g.add(box(w, h, 0.055, wood(0x4a3421)));
  const m = plane(w - 0.10, h - 0.10, mat(0xe6dcc4, { roughness: 0.92 }));
  m.position.z = 0.029; g.add(m);
  const a = plane(w - 0.18, h - 0.18, new THREE.MeshStandardMaterial({ map: paintingTexture(), roughness: 0.88, ...OPT }));
  a.position.z = 0.033; g.add(a);
  a.material.color.setHex(art);
  put(parent, noAim(g), x, y, z, ry);
  return g;
}

/** Flush-mount residential ceiling fixture with a warm frosted shade. */
function ceilingFixture(parent, x, y, z, r = 0.30) {
  const g = new THREE.Group();
  g.add(cyl(r * 0.45, r * 0.55, 0.08, trim(), 18));
  const shade = new THREE.Mesh(
    new THREE.SphereGeometry(r, 20, 10, 0, Math.PI * 2, Math.PI * 0.45, Math.PI * 0.55),
    new THREE.MeshStandardMaterial({ color: 0xf2e3c4, roughness: 0.45, emissive: 0xffdf9f, emissiveIntensity: 0.85, side: THREE.DoubleSide, ...OPT })
  );
  shade.position.y = -0.10; g.add(shade);
  put(parent, noAim(g), x, y, z);
  return g;
}

/**
 * Closed box room: inward-facing walls, floor, ceiling.
 * `lift` adds a matching emissive term to every surface. CCTV rooms read far
 * too dark with lights alone (a point light falls off fast in a big room, and
 * its far corners get nothing), so the surfaces carry some of their own
 * brightness — one uniform beats eight extra dynamic lights, which is what
 * the fragment shader would actually charge us for.
 */
function shell(w, h, d, floorColor, wallColor, lift = 0.34) {
  const g = new THREE.Group();
  const lit = (color) => new THREE.MeshStandardMaterial({
    color,
    roughness: 0.9,
    metalness: 0.05,
    emissive: color,
    emissiveIntensity: lift,
    ...OPT,
  });
  const floor = plane(w, d, lit(floorColor));
  floor.rotation.x = -Math.PI / 2; g.add(floor);
  const ceil = plane(w, d, lit(0x2a2f3d));
  ceil.rotation.x = Math.PI / 2; ceil.position.y = h; g.add(ceil);
  const wallMat = lit(wallColor);
  const add = (pw, x, y, z, ry) => {
    const m = plane(pw, h, wallMat);
    m.position.set(x, y, z); m.rotation.y = ry; g.add(m);
  };
  add(w, 0, h / 2, -d / 2, 0);           // back (faces the camera corner)
  add(w, 0, h / 2, d / 2, Math.PI);      // front
  add(d, -w / 2, h / 2, 0, Math.PI / 2); // left
  add(d, w / 2, h / 2, 0, -Math.PI / 2); // right
  g.userData.lit = lit;
  return g;
}

function put(parent, obj, x, y, z, ry = 0) {
  obj.position.set(x, y, z); obj.rotation.y = ry; parent.add(obj); return obj;
}

/** Remote rooms never move (the subject is a separate object), so freeze them. */
function freezeGroup(g) {
  g.updateMatrixWorld(true);
  g.traverse((o) => { o.matrixAutoUpdate = false; });
  return g;
}

/** CAM 02 — ENTRY HALLWAY: paneled doors, runner, family photos, warm lights. */
function buildHallway() {
  const g = homeShell(4, 3.2, 14, hardwoodTexture(), 0x8f8578, 0.40);
  const doorMat = wood(0x6b4a2b);
  const casing = trim();
  for (const z of [-5, -1, 3]) {
    for (const side of [-1, 1]) {
      const x = 2.0 * side;
      const face = x - 0.055 * side;
      const caseA = box(0.075, 2.32, 0.12, casing);
      noAim(caseA); put(g, caseA, x - 0.005 * side, 1.16, z - 0.66);
      const caseB = box(0.075, 2.32, 0.12, casing);
      noAim(caseB); put(g, caseB, x - 0.005 * side, 1.16, z + 0.66);
      const header = box(0.075, 0.12, 1.44, casing);
      noAim(header); put(g, header, x - 0.005 * side, 2.32, z);
      put(g, box(0.065, 2.08, 1.04, doorMat), x - 0.035 * side, 1.04, z);
      for (const py of [0.58, 1.24, 1.78]) {
        const panel = box(0.018, py > 1.5 ? 0.34 : 0.48, 0.70, wood(0x59391f));
        put(g, panel, face, py, z);
      }
      const knob = new THREE.Mesh(new THREE.SphereGeometry(0.045, 10, 10), mat(0xb8a25e, { roughness: 0.3, metalness: 0.8 }));
      put(g, knob, face - 0.045 * side, 1.02, z + 0.34);
    }
  }
  // Runner rug down the middle; the patrol path crosses it, as in a real hall.
  const runner = plane(1.25, 12.5, new THREE.MeshStandardMaterial({ map: carpetTexture(), roughness: 0.96, ...OPT }));
  runner.rotation.x = -Math.PI / 2;
  put(g, noAim(runner), 0, 0.012, -0.5);
  wallArt(g, -1.96, 2.25, -3.0, Math.PI / 2, 0.66, 0.52, 0xffffff);
  wallArt(g, 1.96, 2.22, 0.8, -Math.PI / 2, 0.58, 0.72, 0xd8e4e8);
  wallArt(g, -1.96, 2.28, 4.4, Math.PI / 2, 0.58, 0.46, 0xc9d8c2);
  for (const z of [-4, 0, 4]) ceilingFixture(g, 0, 3.12, z, 0.28);
  // Plug-in nightlight: a believable warm accent near the far outlet.
  const night = box(0.055, 0.11, 0.075, glowMat(0xffc47a, 1.25));
  put(g, night, 1.965, 0.38, -5.8);
  return g;
}

/** CAM 03 — PANTRY & STORAGE: stocked shelves, totes, linens, utility pegboard. */
function buildStorage() {
  const g = homeShell(9, 3.4, 8, concreteTexture(), 0x8b8378, 0.40);
  const shelfMat = wood(0x6b563d);
  const jarGlass = new THREE.MeshStandardMaterial({ color: 0xcfd8d2, roughness: 0.12, metalness: 0.05, transparent: true, opacity: 0.42, ...OPT });
  const lidMat = mat(0x8f8578, { roughness: 0.45, metalness: 0.55 });

  function pantryJar(x, y, z, fill, h = 0.34) {
    const jar = new THREE.Group();
    const glass = cyl(0.11, 0.11, h, jarGlass, 14); jar.add(glass);
    const goods = cyl(0.095, 0.095, h * 0.72, mat(fill, { roughness: 0.85 }), 12);
    goods.position.y = -h * 0.08; jar.add(goods);
    const lid = cyl(0.115, 0.115, 0.055, lidMat, 14); lid.position.y = h / 2 + 0.028; jar.add(lid);
    const label = plane(0.13, 0.10, mat(0xe6dcc4, { roughness: 0.9 }));
    label.position.set(0, 0, 0.112); jar.add(label);
    jar.position.set(x, y, z); return jar;
  }
  function foodCan(x, y, z, label) {
    const can = new THREE.Group();
    const body = cyl(0.075, 0.075, 0.20, mat(0xb9bec4, { roughness: 0.32, metalness: 0.75 }), 14); can.add(body);
    const band = cyl(0.077, 0.077, 0.11, mat(label, { roughness: 0.6 }), 14); can.add(band);
    const top = cyl(0.075, 0.075, 0.015, lidMat, 14); top.position.y = 0.105; can.add(top);
    can.position.set(x, y, z); return can;
  }
  function tote(x, y, z, color, w = 0.72, h = 0.42, d = 0.52, ry = 0) {
    const t = new THREE.Group();
    t.add(box(w, h, d, mat(color, { roughness: 0.62 })));
    const lid = box(w + 0.045, 0.075, d + 0.045, mat(0xd8d2c2, { roughness: 0.6 }));
    lid.position.y = h / 2 + 0.035;
    t.add(lid);
    const label = plane(Math.min(0.34, w * 0.55), 0.16, mat(0xe6dcc4, { roughness: 0.9 }));
    label.position.set(0, 0, d / 2 + 0.006); t.add(label);
    t.position.set(x, y, z); t.rotation.y = ry; return t;
  }
  function foldedStack(x, y, z, colors) {
    const s = new THREE.Group();
    colors.forEach((c, i) => {
      const f = box(0.58 - (i % 2) * 0.045, 0.13, 0.44, fabric(c));
      f.position.y = i * 0.135; s.add(f);
    });
    s.position.set(x, y, z); return s;
  }

  for (const [sx, sz, sry] of [[-2.8, -2.2, 0], [1.8, -2.2, 0], [-0.4, 2.2, Math.PI]]) {
    const shelf = new THREE.Group();
    for (const y of [0.25, 0.95, 1.65]) {
      const board = box(3.2, 0.08, 0.9, shelfMat); board.position.y = y; shelf.add(board);
      const lip = box(3.2, 0.055, 0.035, wood(0x59391f)); lip.position.set(0, y + 0.065, 0.435); shelf.add(lip);
    }
    for (const x of [-1.5, 1.5]) for (const z of [-0.4, 0.4]) {
      const post = box(0.08, 1.9, 0.08, shelfMat); post.position.set(x, 0.95, z); shelf.add(post);
    }
    shelf.add(pantryJar(-1.15, 0.51, 0.05, 0xc9a24e));
    shelf.add(pantryJar(-0.82, 0.51, -0.08, 0x9c5a2e));
    shelf.add(foodCan(-0.45, 0.39, 0.10, 0xa83a32));
    shelf.add(foodCan(-0.22, 0.39, -0.05, 0x2f6b4f));
    shelf.add(foldedStack(0.55, 0.29, 0.02, [0x9db4c8, 0xc8a86a, 0x7e8b6f]));
    shelf.add(tote(-0.85, 1.24, 0.0, 0x5d6f83));
    shelf.add(pantryJar(0.15, 1.21, 0.08, 0xd8cf9f, 0.30));
    shelf.add(foodCan(0.55, 1.09, -0.06, 0x35506b));
    shelf.add(foodCan(0.78, 1.09, 0.08, 0xa83a32));
    shelf.add(tote(0.55, 1.94, -0.02, 0x8a6a4a, 0.92, 0.36, 0.56));
    shelf.add(foldedStack(-0.95, 1.69, 0.0, [0xb08a8a, 0x6b7a99]));
    put(g, shelf, sx, 0, sz, sry);
  }
  // Floor totes stay low and near the walls so patrol sightlines stay open.
  put(g, tote(0, 0.21, 0, 0x6b7a99, 0.78, 0.42, 0.56, 0.08), 3.35, 0.21, 1.75);
  put(g, tote(0, 0.18, 0, 0x8a6a4a, 0.66, 0.36, 0.50, -0.12), 2.55, 0.18, 2.25);
  put(g, foldedStack(0, 0, 0, [0xc8a86a, 0x9db4c8]), -3.55, 0.065, 1.85);

  // Pegboard with broom, mop, and dustpan on the back wall.
  const peg = plane(2.4, 1.25, mat(0x6b5a43, { roughness: 0.8 }));
  put(g, peg, -0.4, 1.55, -3.965);
  const broom = new THREE.Group();
  broom.add(cyl(0.022, 0.022, 1.25, wood(), 10));
  const broomHead = box(0.24, 0.18, 0.08, mat(0xc9a24e, { roughness: 0.9 }));
  broomHead.position.y = -0.70; broom.add(broomHead);
  put(g, broom, -1.15, 1.45, -3.90, 0.06);
  const mop = new THREE.Group();
  mop.add(cyl(0.022, 0.022, 1.30, wood(), 10));
  const mopHead = cyl(0.09, 0.12, 0.28, fabric(0xd8d2c2), 10);
  mopHead.position.y = -0.76; mop.add(mopHead);
  put(g, mop, -0.65, 1.48, -3.90, -0.05);
  const pan = box(0.30, 0.055, 0.34, mat(0x35506b, { roughness: 0.55 }));
  put(g, pan, -0.05, 0.75, -3.90);

  // Bare-bulb utility light with pull chain.
  const cord = cyl(0.018, 0.018, 0.55, mat(0x1c1c20), 8);
  put(g, cord, 0, 3.12, 0);
  const socket = cyl(0.055, 0.065, 0.09, mat(0x8f8578, { metalness: 0.5, roughness: 0.4 }), 12);
  put(g, socket, 0, 2.80, 0);
  const bareBulb = new THREE.Mesh(new THREE.SphereGeometry(0.085, 14, 12), glowMat(0xffd9a0, 1.7));
  put(g, bareBulb, 0, 2.70, 0);
  const chain = cyl(0.008, 0.008, 0.34, lidMat, 6);
  put(g, chain, 0.09, 2.58, 0);
  for (const [sx, sz, sry] of [[-2.8, -2.2, 0], [1.8, -2.2, 0], [-0.4, 2.2, Math.PI]]) {
    const shade = contactShadow(3.5, 1.25, 0.30);
    put(g, shade, sx, 0.012, sz, sry);
  }
  return g;
}

/** CAM 04 — HOME KITCHEN: cabinets, fridge, stove, sink, and dining set. */
function buildBreak() {
  const g = homeShell(9, 3.2, 8, tileTexture(), 0x8f8578, 0.40);
  const cabinetWood = wood(0x6b4a2b);
  const cabinetDark = wood(0x59391f);

  // Full-height refrigerator where the vending machine used to stand.
  const fridge = new THREE.Group();
  fridge.add(box(1.15, 2.0, 0.72, mat(0xb9bec4, { roughness: 0.32, metalness: 0.72 })));
  for (const s of [-1, 1]) {
    const door = box(0.535, 1.92, 0.025, mat(0xc8ccd2, { roughness: 0.3, metalness: 0.72 }));
    door.position.set(0.28 * s, 0, 0.365);
    fridge.add(door);
    const handle = cyl(0.025, 0.025, 0.72, mat(0x6f757d, { roughness: 0.35, metalness: 0.7 }), 10);
    handle.position.set(0.075 * s, 0.15, 0.40); fridge.add(handle);
  }
  const dispenser = plane(0.24, 0.32, glowMat(0x9fd8ff, 0.55));
  dispenser.position.set(-0.28, 0.28, 0.375); fridge.add(dispenser);
  put(g, fridge, 3.65, 1.0, -3.35);

  // Back-wall kitchen run: lowers, stove, sink, and uppers.
  const run = new THREE.Group(); g.add(run);
  const lowers = box(4.8, 0.86, 0.68, cabinetWood);
  lowers.position.set(-1.1, 0.43, -3.55);
  run.add(lowers);
  const counter = box(4.9, 0.055, 0.76, mat(0xd8d2c2, { roughness: 0.34 }));
  counter.position.set(-1.1, 0.885, -3.55); run.add(counter);
  for (let i = 0; i < 5; i++) {
    const door = box(0.78, 0.62, 0.025, cabinetDark);
    door.position.set(-3.0 + i * 0.95, 0.43, -3.20); run.add(door);
    const knob = new THREE.Mesh(new THREE.SphereGeometry(0.028, 8, 8), mat(0xb8a25e, { roughness: 0.3, metalness: 0.7 }));
    knob.position.set(-2.72 + i * 0.95, 0.43, -3.18); run.add(knob);
  }
  const backsplash = plane(4.9, 0.62, mat(0x9fb4ae, { roughness: 0.35 }));
  backsplash.position.set(-1.1, 1.22, -3.895); run.add(backsplash);
  for (const ux of [-2.75, -1.55, 0.35]) {
    const upper = box(1.05, 0.78, 0.38, cabinetWood);
    upper.position.set(ux, 2.22, -3.70); run.add(upper);
    const under = plane(0.95, 0.055, glowMat(0xffd9a0, 0.85));
    under.rotation.x = Math.PI / 2; under.position.set(ux, 1.82, -3.70); run.add(under);
  }
  // Stove with kettle.
  const stove = box(0.95, 0.86, 0.70, mat(0x2b2e34, { roughness: 0.42, metalness: 0.35 }));
  stove.position.set(0.95, 0.43, -3.50); run.add(stove);
  const ovenFace = plane(0.72, 0.48, mat(0x111318, { roughness: 0.22, metalness: 0.25 }));
  ovenFace.position.set(0.95, 0.38, -3.145); run.add(ovenFace);
  const ovenGlow = plane(0.50, 0.055, glowMat(0xff9c4a, 0.9));
  ovenGlow.position.set(0.95, 0.30, -3.14); run.add(ovenGlow);
  for (const [bx, bz] of [[0.72, -3.68], [1.18, -3.68], [0.72, -3.42], [1.18, -3.42]]) {
    const burner = cyl(0.11, 0.11, 0.025, mat(0x0d0e12, { roughness: 0.5 }), 16);
    burner.position.set(bx, 0.875, bz); run.add(burner);
  }
  const kettle = new THREE.Group();
  kettle.add(cyl(0.13, 0.15, 0.22, mat(0xb03030, { roughness: 0.32, metalness: 0.35 }), 16));
  const spout = cyl(0.025, 0.035, 0.20, mat(0xb03030, { roughness: 0.35 }), 8);
  spout.position.set(0.16, 0.08, 0); spout.rotation.z = -0.5; kettle.add(spout);
  kettle.position.set(0.72, 0.99, -3.68); run.add(kettle);
  // Sink + faucet + dish rack.
  const sink = box(0.72, 0.13, 0.50, mat(0xb4bac2, { roughness: 0.28, metalness: 0.65 }));
  sink.position.set(-2.10, 0.885, -3.55); run.add(sink);
  const basin = box(0.56, 0.055, 0.36, mat(0x7c828c, { roughness: 0.3, metalness: 0.65 }));
  basin.position.set(-2.10, 0.93, -3.55); run.add(basin);
  const faucetBase = cyl(0.035, 0.045, 0.22, mat(0xb4bac2, { roughness: 0.25, metalness: 0.7 }), 10);
  faucetBase.position.set(-2.10, 1.02, -3.78); run.add(faucetBase);
  const faucetArm = cyl(0.028, 0.028, 0.30, mat(0xb4bac2, { roughness: 0.25, metalness: 0.7 }), 10);
  faucetArm.rotation.x = Math.PI / 2; faucetArm.position.set(-2.10, 1.12, -3.64); run.add(faucetArm);
  const rack = box(0.48, 0.055, 0.34, mat(0x35506b, { roughness: 0.6 }));
  rack.position.set(-1.35, 0.94, -3.55); run.add(rack);
  for (let i = 0; i < 3; i++) {
    const plate = cyl(0.11, 0.11, 0.018, mat(0xe6dcc4, { roughness: 0.5 }), 16);
    plate.rotation.x = 0.28; plate.position.set(-1.48 + i * 0.13, 1.02, -3.55); run.add(plate);
  }

  // Kitchen window with tied-back gingham curtains.
  const kwin = new THREE.Group(); kwin.position.set(-2.10, 1.95, -3.955); g.add(kwin);
  const krail = box(1.55, 0.10, 0.10, trim());
  krail.position.y = 0.60;
  kwin.add(krail);
  const kb = box(1.55, 0.10, 0.10, trim()); kb.position.y = -0.60; kwin.add(kb);
  for (const s of [-1, 1]) {
    const st = box(0.10, 1.30, 0.10, trim()); st.position.x = 0.725 * s; kwin.add(st);
  }
  const kglass = plane(1.36, 1.10, new THREE.MeshBasicMaterial({ color: 0x0a1626, ...OPT }));
  kglass.position.z = -0.025; kwin.add(kglass);
  const kmuntV = box(0.035, 1.10, 0.025, trim()); kmuntV.position.z = 0.005; kwin.add(kmuntV);
  const ksill = box(1.75, 0.07, 0.18, trim()); ksill.position.set(0, -0.685, 0.07); kwin.add(ksill);
  noAim(kwin);
  for (const s of [-1, 1]) {
    const panel = plane(0.42, 1.45, new THREE.MeshStandardMaterial({ map: curtainTexture('#6b7a99'), roughness: 0.92, side: THREE.DoubleSide, ...OPT }));
    put(g, noAim(panel), -2.10 + 1.02 * s, 1.95, -3.82);
  }

  // Dining set with a fruit bowl; chairs stay tucked so feeds stay readable.
  const tableMat = wood(0x7a5c38);
  put(g, box(1.8, 0.075, 1.0, tableMat), -1, 0.72, -0.6);
  for (const [lx, lz] of [[-1.75, -0.95], [-0.25, -0.95], [-1.75, -0.25], [-0.25, -0.25]]) {
    put(g, box(0.07, 0.72, 0.07, tableMat), lx, 0.36, lz);
  }
  const bowl = cyl(0.20, 0.12, 0.11, mat(0x35506b, { roughness: 0.45 }), 16);
  put(g, bowl, -1, 0.815, -0.6);
  for (const [fx, fz, fc] of [[-1.12, -0.60, 0xc96a2e], [-0.88, -0.60, 0x9c2f2f], [-1.0, -0.72, 0x7e9c4e]]) {
    const fruit = new THREE.Mesh(new THREE.SphereGeometry(0.055, 10, 8), mat(fc, { roughness: 0.55 }));
    put(g, fruit, fx, 0.90, fz);
  }
  function diningChair(x, z, ry) {
    const c = new THREE.Group();
    c.add(box(0.46, 0.055, 0.44, fabric(0x7e2f2f)));
    c.children[0].position.y = 0.45;
    const back = box(0.46, 0.55, 0.055, fabric(0x7e2f2f));
    back.position.set(0, 0.75, 0.22); c.add(back);
    for (const [lx, lz] of [[-0.19, -0.18], [0.19, -0.18], [-0.19, 0.18], [0.19, 0.18]]) {
      const leg = box(0.055, 0.45, 0.055, wood(0x4a3421));
      leg.position.set(lx, 0.225, lz); c.add(leg);
    }
    put(g, c, x, 0, z, ry);
  }
  diningChair(-1.85, -0.6, Math.PI / 2);
  diningChair(-0.15, -0.6, -Math.PI / 2);
  diningChair(-1.0, 0.22, Math.PI);
  const runner = plane(1.0, 3.0, new THREE.MeshStandardMaterial({ map: carpetTexture(), roughness: 0.96, ...OPT }));
  runner.rotation.x = -Math.PI / 2;
  put(g, noAim(runner), -1.0, 0.012, 0.95);
  ceilingFixture(g, -1.0, 3.12, -0.6, 0.32);
  wallArt(g, 1.5, 2.25, -3.94, 0, 0.66, 0.52, 0xffffff);
  // wall clock
  const clock = cyl(0.22, 0.22, 0.05, mat(0xe6dcc4, { roughness: 0.5 }), 20);
  clock.rotation.x = Math.PI / 2; put(g, clock, 2.45, 2.45, -3.94);
  const face = cyl(0.19, 0.19, 0.055, mat(0x2b2e34, { roughness: 0.5 }), 20);
  face.rotation.x = Math.PI / 2; put(g, face, 2.45, 2.45, -3.935);
  const handH = box(0.025, 0.09, 0.012, mat(0xd8d2c2));
  handH.position.set(2.45, 2.47, -3.90); handH.rotation.z = -1.1; g.add(handH);
  const handM = box(0.018, 0.13, 0.012, mat(0xd8d2c2));
  handM.position.set(2.45, 2.48, -3.905); handM.rotation.z = 0.35; g.add(handM);
  put(g, contactShadow(2.25, 1.45, 0.28), -1, 0.014, -0.6);
  put(g, contactShadow(1.35, 0.95, 0.28), 3.65, 0.012, -3.35);
  put(g, contactShadow(5.0, 1.0, 0.26), -1.1, 0.012, -3.55);
  return g;
}

/** CAM 05 — BASEMENT UTILITY: furnace, water heater, washer/dryer, utility sink. */
function buildBoiler() {
  const g = homeShell(8, 3.6, 8, concreteTexture(), 0x8b8378, 0.40);
  const enamel = mat(0xb9bec4, { roughness: 0.34, metalness: 0.55 });
  const furnaceMat = mat(0x7a7f88, { roughness: 0.48, metalness: 0.45 });

  // Furnace with filter door, sight glass, vent, and return duct.
  const furnace = new THREE.Group(); furnace.position.set(-1.4, 0, -2.45); g.add(furnace);
  const furnaceBody = box(1.45, 2.1, 1.0, furnaceMat);
  furnaceBody.position.y = 1.05;
  furnace.add(furnaceBody);
  const filterDoor = box(0.90, 0.42, 0.025, mat(0x5d626b, { roughness: 0.5, metalness: 0.4 }));
  filterDoor.position.set(0, 0.48, 0.51); furnace.add(filterDoor);
  const sight = plane(0.20, 0.12, glowMat(0xff9c4a, 1.1));
  sight.position.set(0, 1.18, 0.515); furnace.add(sight);
  const vent = cyl(0.16, 0.16, 1.35, enamel, 14);
  vent.position.set(-0.35, 2.75, -0.1); furnace.add(vent);
  const returnDuct = box(1.05, 0.42, 0.62, enamel);
  returnDuct.position.set(0.1, 2.35, -0.12); furnace.add(returnDuct);
  put(g, furnace, -1.4, 0, -2.45);

  // Water heater with pipes, gauge, and drain pan.
  const heater = new THREE.Group(); heater.position.set(0.65, 0, -2.85); g.add(heater);
  const pan = cyl(0.68, 0.68, 0.09, mat(0x8f8578, { metalness: 0.4, roughness: 0.5 }), 20);
  pan.position.y = 0.045; heater.add(pan);
  const tank = cyl(0.56, 0.56, 1.62, enamel, 22);
  tank.position.y = 0.90; heater.add(tank);
  const tankTop = new THREE.Mesh(new THREE.SphereGeometry(0.56, 22, 10, 0, Math.PI * 2, 0, Math.PI / 2), enamel);
  tankTop.position.y = 1.71; heater.add(tankTop);
  const gauge = plane(0.22, 0.22, glowMat(0xffb347, 1.1));
  gauge.position.set(0, 1.25, 0.565); heater.add(gauge);
  for (const s of [-1, 1]) {
    const riser = cyl(0.055, 0.055, 1.05, mat(0x9a7a4a, { metalness: 0.65, roughness: 0.38 }), 10);
    riser.position.set(0.22 * s, 2.05, -0.08); heater.add(riser);
  }
  const heaterDrain = cyl(0.035, 0.035, 0.55, mat(0x9a7a4a, { metalness: 0.6, roughness: 0.4 }), 8);
  heaterDrain.rotation.z = Math.PI / 2; heaterDrain.position.set(0, 0.18, 0.42); heater.add(heaterDrain);
  put(g, heater, 0.65, 0, -2.85);

  // Washer + dryer along the left wall, with detergent and control panels.
  function laundryMachine(z, topLoad) {
    const m = new THREE.Group();
    m.add(box(0.78, 1.02, 0.74, enamel));
    m.children[0].position.y = 0.51;
    const panel = box(0.74, 0.18, 0.10, mat(0x2b2e34, { roughness: 0.45 }));
    panel.position.set(0, 1.08, -0.28); m.add(panel);
    const dial = cyl(0.035, 0.035, 0.03, mat(0xd8d2c2), 12);
    dial.rotation.x = Math.PI / 2; dial.position.set(-0.18, 1.08, -0.22); m.add(dial);
    const cycle = plane(0.18, 0.055, glowMat(0x9fd8ff, 0.7));
    cycle.position.set(0.10, 1.08, -0.225); m.add(cycle);
    if (topLoad) {
      const lid = box(0.68, 0.035, 0.62, mat(0xc8ccd2, { metalness: 0.55, roughness: 0.35 }));
      lid.position.y = 1.035; m.add(lid);
    } else {
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.23, 0.045, 10, 24), mat(0x2b2e34, { roughness: 0.4 }));
      ring.position.set(0, 0.52, 0.375); m.add(ring);
      const doorGlass = new THREE.Mesh(new THREE.CircleGeometry(0.21, 24), mat(0x0d141c, { roughness: 0.12, metalness: 0.25 }));
      doorGlass.position.set(0, 0.52, 0.378); m.add(doorGlass);
      const clothes = new THREE.Mesh(new THREE.CircleGeometry(0.13, 18), fabric(0x7e8b9c));
      clothes.position.set(0, 0.49, 0.382); m.add(clothes);
    }
    m.position.set(-3.35, 0, z); m.rotation.y = Math.PI / 2;
    g.add(m); return m;
  }
  laundryMachine(-0.55, true);
  laundryMachine(0.55, false);
  const detergent = new THREE.Group();
  detergent.add(box(0.24, 0.34, 0.16, mat(0xd86a2e, { roughness: 0.55 })));
  detergent.children[0].position.y = 0.17;
  const cap = cyl(0.055, 0.055, 0.07, mat(0x2b6cb0, { roughness: 0.5 }), 12);
  cap.position.y = 0.375; detergent.add(cap);
  put(g, detergent, -3.30, 1.11, 0.0);

  // Utility sink, shelf supplies, basket, drain, and anti-fatigue mat.
  const sinkBase = box(0.72, 0.78, 0.58, mat(0x9aa0a8, { roughness: 0.5, metalness: 0.3 }));
  put(g, sinkBase, -3.30, 0.39, -2.15);
  const sinkBasin = box(0.60, 0.14, 0.46, mat(0xd2d6dc, { roughness: 0.28, metalness: 0.55 }));
  put(g, sinkBasin, -3.30, 0.84, -2.15);
  const shelf = new THREE.Group(); g.add(shelf);
  const shelfBoard = box(2.0, 0.07, 0.42, wood());
  shelfBoard.position.set(2.35, 1.68, -3.72);
  shelf.add(shelfBoard);
  for (let i = 0; i < 4; i++) {
    const can = cyl(0.075, 0.075, 0.22, mat([0xa83a32, 0x2f6b4f, 0x35506b, 0xc9a24e][i], { roughness: 0.55 }), 12);
    can.position.set(1.65 + i * 0.46, 1.825, -3.72); shelf.add(can);
  }
  const basket = cyl(0.34, 0.27, 0.46, fabric(0x8a6a4a), 14);
  put(g, basket, 2.25, 0.23, 1.55);
  const laundry = new THREE.Mesh(new THREE.SphereGeometry(0.24, 12, 10), fabric(0xd8d2c2));
  laundry.scale.y = 0.48; put(g, laundry, 2.25, 0.48, 1.55);
  const drain = cyl(0.14, 0.14, 0.025, mat(0x3c3e44, { metalness: 0.5, roughness: 0.5 }), 16);
  put(g, drain, 0.8, 0.013, 0.8);
  const workMat = plane(1.5, 1.0, mat(0x3c4048, { roughness: 0.95 }));
  workMat.rotation.x = -Math.PI / 2;
  put(g, noAim(workMat), -0.35, 0.012, -1.0);

  // Wall pipes, valve wheel, edge joists, and utility fixture.
  const pipeMat = mat(0x9a9aa4, { roughness: 0.38, metalness: 0.45 });
  for (let i = 0; i < 3; i++) {
    const pipe = cyl(0.075, 0.075, 7.4, pipeMat, 10);
    pipe.rotation.z = Math.PI / 2; pipe.position.set(0, 3.02 + i * 0.22, 3.68); g.add(pipe);
  }
  for (const px of [-2.5, 0.5, 2.5]) {
    const drop = cyl(0.075, 0.075, 2.1, pipeMat, 10);
    drop.position.set(px, 1.9, 3.68); g.add(drop);
  }
  const wheel = new THREE.Mesh(new THREE.TorusGeometry(0.26, 0.045, 8, 20), mat(0xb03030, { roughness: 0.5, metalness: 0.25 }));
  wheel.position.set(0.5, 1.45, -3.80); g.add(wheel);
  for (let i = 0; i < 3; i++) {
    const spoke = box(0.48, 0.035, 0.035, mat(0xb03030, { roughness: 0.5 }));
    spoke.position.copy(wheel.position); spoke.rotation.z = i * Math.PI / 3; g.add(spoke);
  }
  for (const jx of [-3.55, 3.55]) {
    const joist = box(0.18, 0.24, 8, wood(0x4a3421));
    put(g, noAim(joist), jx, 3.48, 0);
  }
  ceilingFixture(g, 0, 3.48, 0, 0.30);
  wallArt(g, 2.8, 2.25, -3.94, 0, 0.56, 0.44, 0xd8d2c2);
  put(g, contactShadow(1.75, 1.35, 0.30), -1.4, 0.012, -2.45);
  put(g, contactShadow(1.45, 1.45, 0.28), 0.65, 0.012, -2.85);
  put(g, contactShadow(1.05, 1.75, 0.28), -3.35, 0.012, 0.0);
  return g;
}

/**
 * Build the 4 remote stations. Each station:
 * { idx, id, name, signal, group, camera, patrol: [Vector3], light }
 */
export function buildStations(scene, officeGroup) {
  // Every remote room gets: a bright key light, a soft fill from the camera
  // side, and its own ambient term. CCTV feeds read far too dark otherwise.
  const defs = [
    {
      id: 'office', name: 'SECURITY OFFICE', signal: 'LOCAL FEED',
      build: () => null, // the player's room, already built
      offset: new THREE.Vector3(0, 0, 0),
      camPos: new THREE.Vector3(4.3, 3.0, 3.4),
      lookAt: new THREE.Vector3(-1.2, 1.1, -2.6),
      fov: 65,
      lightColor: null,
    },
    {
      id: 'hall', name: 'MAIN HALLWAY', signal: 'AUX-2 · 4fps',
      build: buildHallway,
      offset: new THREE.Vector3(90, 0, 0),
      camPos: new THREE.Vector3(1.6, 2.9, 6.0),
      lookAt: new THREE.Vector3(0, 1.2, -4),
      fov: 70,
      lightColor: 0xcfe0f0, lightI: 7.5, lightY: 2.9, ambient: 0x6a7c94, ambientI: 2.4,
      patrol: [[1.1, 3.5], [-1.1, -3.0], [1.0, -5.5], [-1.0, 2.0]],
    },
    {
      id: 'store', name: 'STORAGE ROOM', signal: 'AUX-3 · 4fps',
      build: buildStorage,
      offset: new THREE.Vector3(180, 0, 0),
      camPos: new THREE.Vector3(4.2, 3.1, 3.6),
      lookAt: new THREE.Vector3(-2, 1.0, -2),
      fov: 65,
      lightColor: 0xffe0b0, lightI: 8.5, lightY: 3.0, ambient: 0x8a7458, ambientI: 2.6,
      patrol: [[2.6, 1.2], [-2.6, -0.5], [0.5, -3.0], [-3.0, 2.4]],
    },
    {
      id: 'break', name: 'BREAK ROOM', signal: 'AUX-4 · 4fps',
      build: buildBreak,
      offset: new THREE.Vector3(270, 0, 0),
      camPos: new THREE.Vector3(4.0, 3.0, 3.4),
      lookAt: new THREE.Vector3(-1.5, 1.1, -2),
      fov: 65,
      lightColor: 0xd6ffe0, lightI: 8.0, lightY: 2.9, ambient: 0x6c8a78, ambientI: 2.6,
      patrol: [[-2.8, 1.6], [0.8, -2.4], [2.8, 0.6], [-0.5, 2.8]],
    },
    {
      id: 'boiler', name: 'BOILER ROOM', signal: 'AUX-5 · 4fps',
      build: buildBoiler,
      offset: new THREE.Vector3(360, 0, 0),
      camPos: new THREE.Vector3(3.6, 3.2, 3.4),
      lookAt: new THREE.Vector3(-1, 1.2, -2),
      fov: 65,
      lightColor: 0xffc9a0, lightI: 8.5, lightY: 3.1, ambient: 0x8a6448, ambientI: 2.8,
      patrol: [[1.8, 2.2], [-2.6, -0.2], [0.2, -2.8], [2.9, -1.0]],
    },
  ];

    return defs.map((d, idx) => {
    let group;
    let light = null;
    let fill = null;
    if (idx === 0) {
      group = officeGroup; // group of office meshes used only for occlusion tests
    } else {
      group = d.build();
      group.position.copy(d.offset);
      scene.add(group);
      freezeGroup(group);
      if (d.lightColor != null) {
        // key light near the ceiling
        light = new THREE.PointLight(d.lightColor, d.lightI, 26, 1.2);
        light.position.set(d.offset.x, d.lightY ?? 2.8, 0);
        scene.add(light);
        // fill from the camera corner so the near wall never goes black
        fill = new THREE.PointLight(d.lightColor, d.lightI * 0.35, 20, 1.2);
        fill.position.set(d.camPos.x + d.offset.x, 2.4, d.camPos.z + d.offset.z);
        scene.add(fill);
        // No per-corner ambients: the shell and prop materials carry a uniform
        // emissive lift instead. Eight fewer dynamic lights keeps the forward
        // renderer (and software test GPUs) fast without darkening CCTV.
      }
    }
    const camera = new THREE.PerspectiveCamera(d.fov, 16 / 9, 0.1, 40);
    const off = idx === 0 ? new THREE.Vector3(0, 0, 0) : d.offset;
    camera.position.copy(d.camPos).add(off);
    const lookPoint = d.lookAt.clone().add(off);
    camera.lookAt(lookPoint);
    camera.updateMatrixWorld();
    const toWorld = (x, z, y = 0) => new THREE.Vector3(x, y, z).add(d.offset);
    return {
      idx,
      camNo: `CAM 0${idx + 1}`,
      id: d.id,
      name: d.name,
      signal: d.signal,
      camPos: camera.position.clone(),
      lookAt: lookPoint,
      group,
      camera,
      light,
      fill,
      lightBase: light ? light.intensity : 0,
      patrol: (d.patrol || []).map(([x, z]) => toWorld(x, z)),
    };
  });
}
