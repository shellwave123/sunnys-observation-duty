// Circle-vs-AABB collision for furniture. Colliders may follow a live
// Object3D (chair, which moves) or enable conditionally (open door swing).
export function buildColliders(refs) {
  return [
    { x: -1.2, z: -2.5, hx: 1.3, hz: 0.5 }, // desk (slightly less back block)
    { ref: refs.chair, hx: 0.35, hz: 0.35 }, // chair (follows it, even mid-anomaly)
    { x: 2.6, z: -3.5, hx: 0.45, hz: 0.3 }, // filing cabinet
    { x: -4.2, z: -3.2, hx: 0.3, hz: 0.3 }, // plant pot
    { door: true, x: 4.0, z: -3.55, hx: 0.55, hz: 0.45 }, // open-door swing area
    { x: 2.35, z: -6.5, hx: 0.5, hz: 2.8 }, // corridor left wall
    { x: 4.85, z: -6.5, hx: 0.5, hz: 2.8 }, // corridor right wall
    { x: -0.4, z: -11.5, hx: 0.6, hz: 2.8 }, // power room left wall
    { x: 7.4, z: -11.5, hx: 0.6, hz: 2.8 }, // power room right wall
    { x: 3.5, z: -14.2, hx: 3.9, hz: 0.5 }, // power room back wall
    { x: 0.9, z: -9.0, hx: 1.6, hz: 0.4 }, // power room front wall (left of corridor mouth)
    { x: 6.1, z: -9.0, hx: 1.4, hz: 0.4 }, // power room front wall (right of corridor mouth)
    { x: 1.0, z: -13.2, hx: 0.5, hz: 0.35 }, // locker 1
    { x: 2.1, z: -13.2, hx: 0.5, hz: 0.35 }, // locker 2
    { x: 0.8, z: -9.8, hx: 0.5, hz: 0.35 }, // locker 3 (hiding spot near entry)
  ];
}

export function resolveCollisions(pos, radius, colliders, refs) {
  for (const c of colliders) {
    if (c.door && Math.abs(refs.doorPivot.rotation.y) < 0.1) continue;
    const cx = c.ref ? c.ref.position.x : c.x;
    const cz = c.ref ? c.ref.position.z : c.z;
    const dx = pos.x - cx;
    const dz = pos.z - cz;
    const px = c.hx + radius - Math.abs(dx);
    if (px <= 0) continue;
    const pz = c.hz + radius - Math.abs(dz);
    if (pz <= 0) continue;
    // Push out along the axis of least penetration.
    if (px < pz) pos.x = cx + Math.sign(dx || 1) * (c.hx + radius);
    else pos.z = cz + Math.sign(dz || 1) * (c.hz + radius);
  }
}
