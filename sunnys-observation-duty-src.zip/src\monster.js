// The stick-figure subject: tall, thin, glowing eyes. Roams a remote
// station on camera, and — if never logged — comes for the office door.
import * as THREE from 'three';
import { audio } from './audio.js';

export const MonsterState = { IDLE: 'idle', PRESENT: 'present', HUNTING: 'hunting', SCARING: 'scaring' };

/** Tall twiggy stick figure with long arms, long fingers, glowing eyes. */
export function buildStickFigure() {
  const root = new THREE.Group();
  const skin = new THREE.MeshStandardMaterial({ color: 0x0f1116, roughness: 0.65, metalness: 0.1, emissive: 0x05070c });
  const limb = (len, r) => new THREE.Mesh(new THREE.CylinderGeometry(r, r * 0.8, len, 8), skin);

  const pelvis = new THREE.Group(); pelvis.position.y = 1.02; root.add(pelvis);

  // torso (pivot at shoulders so it can lean)
  const shoulderBar = new THREE.Group(); shoulderBar.position.y = 1.62; root.add(shoulderBar);
  const torso = limb(0.62, 0.075); torso.position.y = -0.31; shoulderBar.add(torso);

  // neck + horror head: pale cracked skull, void-black eyes, third eye,
  // side eyes, tear streaks, slit nostrils, and a huge jagged grin
  const neck = limb(0.12, 0.045); neck.position.y = 0.06; shoulderBar.add(neck);
  const headG = new THREE.Group(); headG.position.y = 0.26; shoulderBar.add(headG);
  const boneMat = new THREE.MeshStandardMaterial({ color: 0xc9bda6, roughness: 0.55, metalness: 0.0 });
  const voidMat = new THREE.MeshBasicMaterial({ color: 0x030303 });
  const toothMat = new THREE.MeshStandardMaterial({ color: 0xe6d9bd, roughness: 0.4 });
  const crackMat = new THREE.MeshBasicMaterial({ color: 0x140e0c });
  const skull = new THREE.Mesh(new THREE.SphereGeometry(0.21, 24, 18), boneMat);
  skull.scale.set(1.02, 1.18, 0.95); headG.add(skull);
  // every glowing dot shares eyeMat so the locked-on stare burns them all red
  const eyeMat = new THREE.MeshBasicMaterial({ color: 0xffe9a8 });

  const voidEye = (rx, ry, x, y, z) => {
    const e = new THREE.Mesh(new THREE.SphereGeometry(1, 18, 14), voidMat);
    e.scale.set(rx, ry, Math.min(rx, ry) * 0.55);
    e.position.set(x, y, z); headG.add(e);
  };
  const pupil = (r, x, y, z) => {
    const p = new THREE.Mesh(new THREE.SphereGeometry(r, 10, 8), eyeMat);
    p.position.set(x, y, z); headG.add(p);
  };
  // the two huge void eyes + pin pupils
  voidEye(0.075, 0.115, -0.105, 0.05, 0.15);
  voidEye(0.075, 0.115, 0.105, 0.05, 0.15);
  pupil(0.017, -0.105, 0.035, 0.22);
  pupil(0.017, 0.105, 0.035, 0.22);
  // vertical third eye on the forehead
  voidEye(0.032, 0.046, 0, 0.175, 0.172);
  pupil(0.01, 0, 0.175, 0.203);
  // small side eyes on both cheeks
  for (const s of [-1, 1]) {
    voidEye(0.02, 0.024, 0.185 * s, -0.02, 0.098);
    pupil(0.007, 0.185 * s, -0.02, 0.118);
    voidEye(0.016, 0.02, 0.175 * s, -0.095, 0.112);
    pupil(0.006, 0.175 * s, -0.095, 0.128);
  }
  // forehead crack (two tilted segments hugging the skull curve)
  const scar = (w, h, x, y, z, rz, rx) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, 0.01), crackMat);
    m.position.set(x, y, z); m.rotation.z = rz; m.rotation.x = rx; headG.add(m);
  };
  scar(0.01, 0.075, 0.014, 0.112, 0.178, 0.35, 0.3);
  scar(0.01, 0.06, -0.004, 0.05, 0.193, -0.25, 0.15);
  // long black tear streaks dripping from the big eyes
  const tear = (w, h, x, y) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, 0.008), voidMat);
    m.position.set(x, y, 0.15); headG.add(m);
  };
  tear(0.022, 0.2, -0.115, -0.1);
  tear(0.016, 0.13, -0.075, -0.06);
  tear(0.022, 0.17, 0.115, -0.09);
  // slit nostrils
  for (const s of [-1, 1]) {
    const n = new THREE.Mesh(new THREE.BoxGeometry(0.014, 0.04, 0.008), voidMat);
    n.position.set(0.024 * s, -0.055, 0.188); headG.add(n);
  }
  // the grin: a wide dark maw with two ragged rows of teeth.
  // The lower jaw is its own pivot so it can drop open — a permanently
  // closed mouth reads as a mask, and the yawn gape is the whole scare.
  const jaw = new THREE.Group();
  jaw.position.set(0, -0.105, 0.10);
  headG.add(jaw);
  const maw = new THREE.Mesh(new THREE.SphereGeometry(0.13, 20, 14), voidMat);
  maw.scale.set(1.7, 0.62, 0.5); maw.position.set(0, -0.07, 0); jaw.add(maw);
  const toothGeo = new THREE.ConeGeometry(0.024, 0.07, 6);
  for (let i = 0; i < 11; i++) {
    const t = new THREE.Mesh(toothGeo, toothMat);
    const x = -0.175 + (i / 10) * 0.35;
    t.scale.setScalar(0.75 + (((i * 37) % 10) / 10) * 0.6); // ragged lengths
    t.position.set(x, -0.112, 0.152 - Math.abs(x) * 0.15);
    t.rotation.x = Math.PI; // point down
    t.rotation.z = Math.sin(i * 7.3) * 0.12;
    headG.add(t);
  }
  for (let i = 0; i < 9; i++) {
    const t = new THREE.Mesh(toothGeo, toothMat);
    const x = -0.15 + (i / 8) * 0.3;
    t.scale.setScalar(0.7 + (((i * 53) % 10) / 10) * 0.6);
    t.position.set(x, -0.133, 0.048 - Math.abs(x) * 0.15);
    t.rotation.z = Math.sin(i * 5.1 + 1) * 0.12;
    jaw.add(t);
  }

  // arms: shoulder pivots -> elbow groups -> long fingers
  const mkArm = (side) => {
    const sh = new THREE.Group(); sh.position.set(0.19 * side, 0, 0); shoulderBar.add(sh);
    const up = limb(0.5, 0.045); up.position.y = -0.25; sh.add(up);
    const el = new THREE.Group(); el.position.y = -0.5; sh.add(el);
    const fo = limb(0.62, 0.036); fo.position.y = -0.31; el.add(fo);
    const hand = new THREE.Group(); hand.position.y = -0.62; el.add(hand);
    for (let i = 0; i < 4; i++) {
      const f = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.008, 0.2, 6), skin);
      f.position.set((i - 1.5) * 0.035, -0.1, 0); hand.add(f);
    }
    return { sh, el };
  };
  const armL = mkArm(-1); const armR = mkArm(1);

  // legs: hip pivots -> knee groups -> feet
  const mkLeg = (side) => {
    const hip = new THREE.Group(); hip.position.set(0.11 * side, 0, 0); pelvis.add(hip);
    const th = limb(0.5, 0.055); th.position.y = -0.25; hip.add(th);
    const knee = new THREE.Group(); knee.position.y = -0.5; hip.add(knee);
    const sh2 = limb(0.52, 0.044); sh2.position.y = -0.26; knee.add(sh2);
    const foot = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.06, 0.22), skin);
    foot.position.set(0, -0.52, 0.06); knee.add(foot);
    return { hip, knee };
  };
  const legL = mkLeg(-1); const legR = mkLeg(1);

  // taller, wrong proportions: stretched torso, head too big, arms too long
  root.scale.set(1.0, 1.22, 1.0);
  headG.scale.setScalar(1.18);
  // faint blood-red glow cast from its face so it reads in dark rooms/feeds
  const faceGlow = new THREE.PointLight(0xff2a1a, 1.6, 5, 1.6);
  faceGlow.position.set(0, 0.1, 0.5); headG.add(faceGlow);
  root.traverse((o) => { if (o.isMesh) { o.castShadow = false; o.receiveShadow = false; } });
  return { root, refs: { shoulderBar, headG, jaw, armL, armR, legL, legR }, eyeMat };
}

function wrapAngle(d) {
  while (d > Math.PI) d -= Math.PI * 2;
  while (d < -Math.PI) d += Math.PI * 2;
  return d;
}

export class MonsterManager {
  constructor(scene) {
    this.scene = scene;
    const { root, refs, eyeMat } = buildStickFigure();
    root.visible = false;
    root.userData.anomalyType = 'monster';
    root.userData.isActive = false;
    root.traverse((o) => { o.userData.anomalyType = 'monster'; o.userData.isActive = false; });
    scene.add(root);
    this.fig = root;
    this.r = refs;
    this.eyeMat = eyeMat;
    this.eyeBase = new THREE.Color(0xffe9a8);
    // A scare can leave the rig twisted. Remember the build-time pose so a
    // reset always returns a neutral body, not a leftover jumpscare shape.
    this.restPose = [];
    root.traverse((o) => { if (o.isObject3D) this.restPose.push([o, o.rotation.clone()]); });
    this.faceCam = null; // station camera it is currently staring into
    this.dread = 0;      // 0..1 how locked-on the stare is
    this.state = MonsterState.IDLE;
    this.stationIndex = -1;  // which station it haunts right now
    this.patrol = [];        // waypoints (world)
    this.nextIdx = 0;
    this.dwell = 0;
    this.warnedHunt = false;
    this.huntT = 0;
    this.scareT = 0;
    this.scareDur = 1.25;   // length of the caught-jumpscare lunge
    this.scareCam = null;   // camera it is rushing, held for the whole lunge
    this.t = 0;
    this.stare = 0;          // countdown while it freezes and stares at the camera
    this.walkSpeed = 1.15;
    this.work = { v1: new THREE.Vector3(), v2: new THREE.Vector3(), v3: new THREE.Vector3() };
  }

  reset() {
    this.fig.visible = false;
    // park it far below the world so the invisible body can never
    // intercept a report ray meant for something behind it
    this.fig.position.set(0, -60, 0);
    for (const [o, rot] of this.restPose) o.rotation.copy(rot);
    this.state = MonsterState.IDLE;
    this.stationIndex = -1;
    this.t = 0;
    this.faceCam = null;
    this.warnedHunt = false;
    this.setDread(0);
  }

  get present() { return this.state === MonsterState.PRESENT; }
  get hunting() { return this.state === MonsterState.HUNTING; }

  /** Locked-on stare 0..1: eyes burn from corpse-pale to blood-red. */
  setDread(d) {
    this.dread = Math.max(0, Math.min(1, d));
    this.eyeMat.color.setRGB(1, 0.85 - 0.78 * this.dread, 0.7 - 0.64 * this.dread);
  }

  /** Appear in a remote station (index >= 1). */
  spawn(stationIndex, patrol, dwellSeconds) {
    this.reset();
    this.state = MonsterState.PRESENT;
    this.stationIndex = stationIndex;
    this.patrol = patrol;
    this.nextIdx = Math.floor(Math.random() * patrol.length);
    this.dwell = dwellSeconds;
    this.warnedHunt = false;
    this.fig.visible = true;
    this.fig.position.copy(patrol[this.nextIdx]);
    audio.spawn();
  }

  /** Logged on camera: scream + vanish. */
  report() {
    audio.scream();
    this.reset();
  }

  /** Dwell expired: head for the office door. */
  beginHunt(doorSpot) {
    this.state = MonsterState.HUNTING;
    this.huntT = 7; // seconds to reach the player
    this.fig.visible = true;
    this.fig.position.copy(doorSpot); // just inside the office doorway
    this.fig.rotation.y = Math.PI;    // facing into the room
  }

  /** Player caught: it rushes the lens instead of hanging there twitching. */
  beginScare(camera) {
    this.state = MonsterState.SCARING;
    this.scareT = this.scareDur;
    this.scareCam = camera;
    const fwd = this.work.v1.set(0, 0, -1).applyQuaternion(camera.quaternion);
    this.fig.position.copy(camera.position).add(fwd.multiplyScalar(0.78));
    this.fig.position.y = Math.max(0.4, camera.position.y - 0.55);
    // Yaw-only facing: a full lookAt would leave pitch/roll behind for the
    // next spawn, glimpse, or report ray.
    this.fig.rotation.set(0, Math.atan2(camera.position.x - this.fig.position.x, camera.position.z - this.fig.position.z), 0);
  }

  get scaring() { return this.state === MonsterState.SCARING; }

  /** Per-frame. hooks: onHuntStart, onGone({logged}|{escaped}|{hunt}), onCaught. */
  update(dt, hooks = {}) {
    if (this.state === MonsterState.IDLE) return;
    this.t += dt;
    const { v1, v2 } = this.work;
    const R = this.r;

    if (this.state === MonsterState.PRESENT) {
      this.dwell -= dt;
      if (this.dwell <= 6 && !this.warnedHunt) {
        // about to come for the door: rattle it first
        this.warnedHunt = true;
        hooks.onHuntWarning?.();
      }
      if (this.dwell <= 0) {
        // expired unlogged: the caller starts the office hunt (door spot, UI).
        hooks.onHuntStart?.();
        return;
      }
      // Staring into a lens: freeze the body, turn the head to the camera.
      if (this.faceCam) {
        v1.subVectors(this.faceCam.position, this.fig.position);
        this.fig.rotation.y += wrapAngle(Math.atan2(v1.x, v1.z) - this.fig.rotation.y) * Math.min(1, dt * 4);
        R.headG.rotation.x = 0.2;
        R.headG.rotation.z = Math.sin(this.t * 3.1) * 0.05;
        R.shoulderBar.rotation.x = 0.1;
        R.legL.hip.rotation.x *= 0.9; R.legR.hip.rotation.x *= 0.9;
        R.armL.sh.rotation.x = -0.55; R.armR.sh.rotation.x = -0.55;
        // it parts its lips as it locks on
        R.jaw.rotation.x += (0.10 + this.dread * 0.22 - R.jaw.rotation.x) * Math.min(1, dt * 5);
        this.fig.position.y = Math.sin(this.t * 1.6) * 0.012;
        return;
      }
      R.shoulderBar.rotation.x *= 0.9;
      const dest = this.patrol[this.nextIdx];
      v1.subVectors(dest, this.fig.position); v1.y = 0;
      const dist = v1.length();
      if (this.stare > 0) {
        // frozen, staring — only the head twitches
        this.stare -= dt;
        R.legL.hip.rotation.x *= 0.9; R.legR.hip.rotation.x *= 0.9;
        R.armL.sh.rotation.x *= 0.9; R.armR.sh.rotation.x *= 0.9;
        R.headG.rotation.z = Math.sin(this.t * 7) * 0.14;
        // it breathes, and it is very slightly too tall to be human
        this.fig.position.y = Math.sin(this.t * 1.5) * 0.012;
        if (this.stare <= 0) R.headG.rotation.z = 0;
      } else if (dist < 0.35) {
        this.nextIdx = (this.nextIdx + 1 + Math.floor(Math.random() * 2)) % this.patrol.length;
        if (Math.random() < 0.35) this.stare = 1.2 + Math.random() * 1.6; // sometimes it just stops
        // idle sway in the corner: weight shifting, head drifting
        R.headG.rotation.y = Math.sin(this.t * 0.9) * 0.16;
        R.headG.rotation.x = 0.05 + Math.sin(this.t * 0.7) * 0.05;
        R.shoulderBar.rotation.z = Math.sin(this.t * 0.8) * 0.05;
        this.fig.position.y = Math.sin(this.t * 1.4) * 0.010;
      } else {
        // walk toward the waypoint
        v1.normalize();
        this.fig.position.addScaledVector(v1, Math.min(this.walkSpeed * dt, dist));
        const yaw = Math.atan2(v1.x, v1.z);
        this.fig.rotation.y += wrapAngle(yaw - this.fig.rotation.y) * Math.min(1, dt * 5);
        // walk cycle — asymmetric: the limbs drag a little, the head lolls
        const s = Math.sin(this.t * 5.4);
        R.legL.hip.rotation.x = s * 0.55;
        R.legR.hip.rotation.x = -s * 0.55;
        R.legL.knee.rotation.x = Math.max(0, -s) * 0.7;
        R.legR.knee.rotation.x = Math.max(0, s) * 0.7;
        R.armL.sh.rotation.x = -s * 0.4;
        R.armR.sh.rotation.x = s * 0.4;
        R.armL.el.rotation.x = -0.25;
        R.armR.el.rotation.x = -0.25;
        R.shoulderBar.rotation.z = s * 0.09; // torso counter-roll
        R.shoulderBar.rotation.x = 0.06 + Math.abs(s) * 0.05;
        R.jaw.rotation.x += (0.05 + Math.abs(s) * 0.03 - R.jaw.rotation.x) * Math.min(1, dt * 4);
        this.fig.position.y = Math.abs(Math.cos(this.t * 5.4)) * 0.035;
        R.headG.rotation.x = 0.06;
        R.headG.rotation.y = 0;
        R.headG.rotation.z = s * 0.05;
      }
      return;
    }

    if (this.state === MonsterState.HUNTING) {
      this.huntT -= dt;
      // Lurching creep in: legs drag, head lolls side to side, and it
      // advances faster the closer it gets — the last second is a lunge.
      const urgency = 1 - Math.max(0, Math.min(1, this.huntT / 7));
      const creep = Math.sin(this.t * (2.0 + urgency * 4.5));
      // violent head twitching that worsens as it closes in
      R.headG.rotation.z = Math.sin(this.t * (2.2 + urgency * 6.0)) * (0.1 + urgency * 0.25);
      R.headG.rotation.x = 0.25 + creep * 0.12;
      R.headG.rotation.y = Math.sin(this.t * 3.7) * urgency * 0.3;
      // the jaw drops further open the closer it gets
      R.jaw.rotation.x += (0.25 + urgency * 0.55 - R.jaw.rotation.x) * Math.min(1, dt * 4);
      R.armL.sh.rotation.x = -0.5 + Math.sin(this.t * 1.8) * 0.08 - urgency * 0.6;
      R.armR.sh.rotation.x = -0.5 - Math.sin(this.t * 1.8) * 0.08 - urgency * 0.6;
      R.armL.el.rotation.x = -0.35 - urgency * 0.7;
      R.armR.el.rotation.x = -0.35 - urgency * 0.7;
      R.shoulderBar.rotation.z = creep * (0.12 + urgency * 0.15);
      R.legL.hip.rotation.x = creep * 0.35;
      R.legR.hip.rotation.x = -creep * 0.35;
      R.legL.knee.rotation.x = Math.max(0, -creep) * 0.5;
      R.legR.knee.rotation.x = Math.max(0, creep) * 0.5;
      this.fig.position.z = Math.min(
        this.fig.position.z + dt * (0.22 + urgency * 0.55),
        -2.2
      );
      this.fig.position.y = Math.abs(Math.cos(this.t * (2.0 + urgency * 3.0))) * 0.03;
      if (this.huntT <= 0) {
        hooks.onHuntResolve?.();
        return;
      }
      return;
    }

    if (this.state === MonsterState.SCARING) {
      // It closes on the lens the whole time, accelerating in, so the last
      // frames are the face filling the screen rather than a static prop.
      this.scareT -= dt;
      const cam = this.scareCam;
      const k = 1 - THREE.MathUtils.clamp(this.scareT / this.scareDur, 0, 1); // 0 -> 1
      if (cam) {
        v1.set(0, 0, -1).applyQuaternion(cam.quaternion);
        // 0.78m -> 0.34m, easing in so the last third is a slam
        const dist = 0.78 - 0.44 * (k * k);
        this.fig.position.copy(cam.position).add(v1.multiplyScalar(dist));
        this.fig.position.y = Math.max(0.35, cam.position.y - 0.55 - 0.12 * k);
        this.fig.rotation.set(0, Math.atan2(cam.position.x - this.fig.position.x, cam.position.z - this.fig.position.z), 0);
      }
      // Chaotic twitch: a random walk reads far worse than a clean sine.
      R.headG.rotation.z += ((Math.random() - 0.5) * 0.7 - R.headG.rotation.z) * Math.min(1, dt * 30);
      R.headG.rotation.x = 0.38 + (Math.random() - 0.5) * 0.45;
      R.headG.rotation.y = (Math.random() - 0.5) * 0.45;
      // Jaw works harder as it gets closer.
      R.jaw.rotation.x = 0.45 + Math.abs(Math.sin(this.t * 19)) * (0.65 + 0.4 * k);
      // shoulders and torso judder too, not just the head
      R.shoulderBar.rotation.x = 0.2 + (Math.random() - 0.5) * 0.4;
      R.shoulderBar.rotation.z = (Math.random() - 0.5) * 0.3;
      if (this.scareT <= 0) {
        this.scareCam = null;
        hooks.onCaught?.();
      }
    }
  }
}
