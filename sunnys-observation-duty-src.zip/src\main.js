import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { gameState, resetGame, GamePhase, nightConfig, saveBestNight } from './gameState.js';
import { createPlayer } from './player.js';
import { createFlashlight } from './flashlight.js';
import { buildRoom } from './room.js';
import { AnomalyManager, REPORT_RANGE } from './anomalies.js';
import { buildColliders, resolveCollisions } from './collisions.js';
import { createQuality } from './quality.js';
import { buildStations } from './rooms.js';
import { MonsterManager, MonsterState } from './monster.js';
import { createMonitor } from './monitor.js';
import { createHand } from './hand.js';
import { createScareDirector } from './scare.js';
import { showToast, updateHUD, showScreen, hideScreens, showNightCard } from './ui.js';
import { audio } from './audio.js';

// --- Scene setup ---
const canvas = document.getElementById('game');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5)); // cap for smooth framerate
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.shadowMap.bias = -0.0005;
renderer.physicallyCorrectLights = true;
renderer.toneMapping = THREE.ACESFilmicToneMapping; // filmic look (applied in OutputPass)
renderer.toneMappingExposure = 1.65;
renderer.outputColorSpace = THREE.SRGBColorSpace;

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x05060a);
scene.fog = new THREE.FogExp2(0x05060a, 0.05); // moodier darkness, preserves camera clarity
// Low image-based ambient for PBR materials: wood, fabric, enamel, and brass
// get believable shape and sheen without adding more dynamic lights.
const pmrem = new THREE.PMREMGenerator(renderer);
scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
scene.environmentIntensity = 0.25; // richer PBR sheen, keep CCTV punchy in feed render
pmrem.dispose();

const camera = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.1, 60);

const refs = buildRoom(scene);
const colliders = buildColliders(refs);
// Storm light: lightning flashes through the window (normally dark).
const storm = new THREE.DirectionalLight(0xbfd4ff, 0);
storm.position.set(-8, 6, -10);
scene.add(storm);
storm.target.position.set(0, 1, 0);
scene.add(storm.target);
const player = createPlayer(camera, renderer.domElement, (pos) => resolveCollisions(pos, 0.35, colliders, refs));
const flashlight = createFlashlight(camera, scene);
const anomalies = new AnomalyManager(refs);
const stations = buildStations(scene, null);
const monster = new MonsterManager(scene);
const monitor = createMonitor({ renderer, scene, stations, monster });
// First-person hand viewmodel: its own scene + camera, drawn after the world.
const hand = createHand();
const scare = createScareDirector({ refs, monster, storm });
const raycaster = new THREE.Raycaster();
raycaster.far = 20;

// Post-processing: subtle bloom so the lamp, screen, moon and eyes glow.
const composer = new EffectComposer(renderer);
composer.addPass(new RenderPass(scene, camera));
const bloom = new UnrealBloomPass(new THREE.Vector2(window.innerWidth, window.innerHeight), 0.65, 0.7, 0.85);
composer.addPass(bloom);
composer.addPass(new OutputPass());

// Drops bloom/shadows/render-scale automatically if the GPU can't keep up.
const quality = createQuality({
  renderer, composer, bloomPass: bloom, scene, camera, shadowLight: flashlight.spot,
});
quality.apply();

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  quality.resize();
});

/** Request pointer lock without unhandled promise rejections. */
function lockPointer() {
  try {
    const r = renderer.domElement.requestPointerLock?.();
    r?.catch?.(() => {});
  } catch { /* pointer lock unavailable (e.g. headless) */ }
}

// --- Input: flashlight + report ---
const REPORT_COOLDOWN = 1.5; // seconds between R presses
let reportCooldown = 0;

window.addEventListener('keydown', (e) => {
  if (e.code === 'Escape') {
    if (deathT > 0) return; // the kill plays out
    if (monitor.open) { standUp(); return; }
    if (player.mode === 'hide') { unhide(); return; }
    if (gameState.phase === GamePhase.PLAYING) pauseGame();
    else if (gameState.phase === GamePhase.PAUSED) resumeGame();
    return;
  }
  if (gameState.phase !== GamePhase.PLAYING || monster.scaring || deathT > 0) return;
  if (e.code === 'KeyF') { flashlight.toggle(); hand.setTorch(flashlight.on); audio.click(); }
  if (e.code === 'KeyR') reportCurrent();
  if (e.code === 'KeyE') toggleMonitor();
  if (e.code === 'KeyH') toggleHide();
  if (e.code === 'KeyN') { if (monitor.open) switchCam(() => monitor.next()); }
  if (e.code === 'KeyB') { if (monitor.open) switchCam(() => monitor.prev()); }
  if (/^Digit[1-5]$/.test(e.code) && monitor.open) {
    const ix = Number(e.code.slice(5)) - 1;
    switchCam(() => monitor.select(ix));
  }
});

// Zoom the CCTV feed with the wheel; pan the zoomed view with mouse drift.
window.addEventListener('wheel', (e) => {
  if (!monitor.open || gameState.phase !== GamePhase.PLAYING) return;
  e.preventDefault();
  if (e.deltaY > 0) monitor.zoomOut(); else monitor.zoomIn();
  audio.click();
}, { passive: false });
    document.addEventListener('mousemove', (e) => {
      if (gameState.phase !== GamePhase.PLAYING) return;
      if (monitor.open) {
        monitor.setPan(monitor.state.panX + e.movementX * 0.0016, monitor.state.panY - e.movementY * 0.0016);
        return;
      }
      if (player.mode === 'hide') {
        player.yaw -= e.movementX * 0.0022;
        player.pitch -= e.movementY * 0.0022;
        player.pitch = Math.max(-1.3, Math.min(1.3, player.pitch));
        return;
      }
    });

// Esc while pointer-locked exits the lock (browser reserves Esc);
// auto-pause in that case. endGame() sets the phase first, so the
// lock exit on win/lose never opens the pause menu.
document.addEventListener('pointerlockchange', () => {
  if (document.pointerLockElement !== renderer.domElement && gameState.phase === GamePhase.PLAYING) {
    pauseGame();
  }
});

function pauseGame() {
  if (gameState.phase !== GamePhase.PLAYING) return;
  gameState.phase = GamePhase.PAUSED;
  if (monitor.open) standUp();
  document.exitPointerLock?.();
  audio.suspend();
  document.getElementById('pause-night').textContent =
    `Night ${gameState.night} · ${gameState.reports} logged · 👁 ${gameState.monstersLogged} subjects`;
  document.getElementById('pause-screen').classList.remove('hidden');
}

function resumeGame() {
  if (gameState.phase !== GamePhase.PAUSED) return;
  audio.unlock(); audio.resume(); audio.click();
  gameState.phase = GamePhase.PLAYING;
  document.getElementById('pause-screen').classList.add('hidden');
  lockPointer();
}

// --- Desk monitor + hiding ---
const DESK_SPOT = new THREE.Vector3(-1.2, 1.6, -2.2);
const HIDE_RADIUS = 2.6;
const distToDesk = () => Math.hypot(player.pos.x - DESK_SPOT.x, player.pos.z - DESK_SPOT.z);

function toggleMonitor() {
  if (monitor.open) { standUp(); return; }
  if (player.mode === 'hide') { unhide(); }
  if (distToDesk() > HIDE_RADIUS) {
    showToast('Get to the desk to use the monitor (E)', 'warn');
    audio.deny();
    return;
  }
  player.setMode('desk');
  hand.sync();
  monitor.open_();
  audio.click();
  audio.chairScrape();
  audio.startHum();
}

function standUp() {
  monitor.close();
  audio.stopHum();
  if (player.mode === 'desk') player.setMode('walk');
  // sometimes it is standing where you were sitting
  const t = gameState.elapsed;
  if (debugTuning.behindChance > 0 && monster.state === MonsterState.IDLE && !scare.glimpseActive
      && t - debugTuning.lastBehindScare > 45 && Math.random() < debugTuning.behindChance) {
    debugTuning.lastBehindScare = t;
    scare.glimpse(2.0, 2, false);
  }
}

/** Switching feeds: static burst, and a blast if the subject is there. */
function switchCam(fn) {
  fn();
  monitor.staticBurst(1.0);
  if (monster.present && monster.stationIndex === monitor.state.index) audio.staticBurst();
  else audio.camSwitch();
}

function distToBed() {
  const x = camera.position.x, z = camera.position.z;
  return Math.hypot(x - (-4.0), z - (-0.2));
}
const distToLocker = () => {
  // simple: closest of common locker anchors
  const candidates = [
    { x: 0.9, z: -13.0 },
    { x: 2.1, z: -13.0 },
    { x: 0.8, z: -9.8 },
  ];
  let best = 99;
  for (const p of candidates) {
    const d = Math.hypot(player.pos.x - p.x, player.pos.z - p.z);
    if (d < best) best = d;
  }
  return best;
};
function toggleHide() {
  const hideEl = document.getElementById('hiding');
  if (player.mode === 'hide') { unhide(); return; }
  if (monitor.open) monitor.close();
  if (player.mode === 'desk' || distToDesk() <= HIDE_RADIUS) {
    player.setMode('hide');
    hideEl?.classList.remove('hidden');
    hand.sync();
    audio.click();
    audio.chairScrape();
  } else if (distToBed() <= 1.9) {
    player.POSES.hide.pos.set(-4.0, 0.32, -0.2);
    player.setMode('hide');
    hideEl?.classList.remove('hidden');
    hand.sync();
    showToast('Hidden under the bed — stay quiet', 'info');
  } else if (distToLocker() <= 1.5) {
    // hiding inside a power-room locker: crouch in place
    player.POSES.hide.pos.set(player.pos.x, 0.9, player.pos.z);
    player.setMode('hide');
    hideEl?.classList.remove('hidden');
    hand.sync();
    audio.click();
    showToast('Hidden in the locker — stay quiet', 'info');
  } else {
    showToast('Get back to hide: under desk, under bed, or in a locker (H)', 'warn');
    audio.deny();
  }
}

function unhide() {
  document.getElementById('hiding')?.classList.add('hidden');
  if (player.mode === 'hide') player.setMode('walk');
}

function aimRay() {
  raycaster.setFromCamera(new THREE.Vector2(0, 0), camera);
  return raycaster;
}

/** R dispatches to the feed when seated, the room otherwise. */
function reportCurrent() {
  if (monitor.open) reportSubject();
  else reportAnomaly();
}

/** Report the stick-figure subject on the selected camera feed. */
function reportSubject() {
  if (reportCooldown > 0) {
    showToast(`⏳ SCANNER RECHARGING (${reportCooldown.toFixed(1)}s)`, 'warn');
    return;
  }
  reportCooldown = REPORT_COOLDOWN;
  audio.click();
  hand.punch(0.6);
  cameraFlash();
  const res = monitor.inspect();
  if (res.visible) {
    const st = monitor.station;
    monster.report();
    resetStare();
    gameState.reports += 1;
    gameState.monstersLogged += 1;
    hand.punch(1.0);
    audio.shutter();
    audio.chime();
    showToast(`✅ SUBJECT LOGGED: ${st.camNo} ${st.name}`, 'good');
    monitor.refreshDom();
  } else {
    const why = {
      empty: 'no subject on this feed',
      offscreen: 'nothing in view — switch cam / move the mouse',
      blocked: 'the subject is obstructed',
      toosmall: 'too small to identify — ZOOM IN (wheel)',
    }[res.reason] ?? 'no subject';
    falseReport(`❌ FALSE REPORT — ${why}`);
  }
}

/** Brief white camera-flash overlay on every report press. */
function cameraFlash() {
  const el = document.getElementById('flash');
  if (!el) return;
  el.classList.remove('go');
  void el.offsetWidth; // restart CSS animation
  el.classList.add('go');
}

function falseReport(msg) {
  audio.buzz();
  hand.punch(0.45); // a half-hearted jab
  showToast(msg, 'bad');
  // No strikes anymore — false reports only cost you time. The subject is
  // the only thing that can end your shift.
}

function reportAnomaly() {
  if (gameState.phase !== GamePhase.PLAYING) return;
  if (reportCooldown > 0) {
    showToast(`⏳ SCANNER RECHARGING (${reportCooldown.toFixed(1)}s)`, 'warn');
    return;
  }
  reportCooldown = REPORT_COOLDOWN;

  // Click + flash on EVERY report press (valid or not).
  audio.click();
  hand.punch(1.0); // you physically slam the report button
  cameraFlash();

  // 1. Cast a ray from the center of the screen.
  const result = anomalies.resolveAim(aimRay(), scene);

  // 2. Must hit something.
  if (!result.hit) {
    falseReport('❌ FALSE REPORT — nothing there');
    return;
  }

  // 3. Must be within range.
  if (result.distance > REPORT_RANGE) {
    falseReport(`❌ FALSE REPORT — target too far (${result.distance.toFixed(1)}m > ${REPORT_RANGE}m)`);
    return;
  }

  // 4. Must be lit by the flashlight beam.
  if (!flashlight.isPointLit(result.point)) {
    falseReport('❌ FALSE REPORT — target is in darkness (shine the 🔦 beam on it)');
    return;
  }

  // 4b. A glimpse: the subject flickered INTO the office with you.
  if (result.anomalyType === 'monster' && scare.glimpseActive) {
    scare.resolveGlimpse();
    resetStare();
    gameState.reports += 1;
    gameState.monstersLogged += 1;
    audio.shutter();
    audio.chime();
    showToast('✅ SUBJECT LOGGED — IT WAS IN THE ROOM', 'good');
    return;
  }

  // 4c. The subject itself, caught at the office door: drive it off.
  if (result.anomalyType === 'monster' && monster.hunting) {
    monster.report(); // scream + vanish
    stopHunt();
    resetStare();
    gameState.reports += 1;
    gameState.monstersLogged += 1;
    audio.shutter();
    audio.chime();
    showToast('✅ SUBJECT DRIVEN OFF — THE DOOR SLAMS', 'good');
    return;
  }
  // 5. Hit object must be a currently-active anomaly.
  if (result.isActive && result.instance) {
    anomalies.fix(result.instance.def);
    gameState.reports += 1;
    audio.shutter();
    audio.chime();
    showToast(`✅ ANOMALY LOGGED: ${result.instance.def.label}`, 'good');
  } else {
    falseReport('❌ FALSE REPORT');
  }
}

// --- The stare: watch a live subject too long and it watches back ---
const debugTuning = { stareLimit: 10, behindChance: 0.25, lastBehindScare: -999 }; // seconds of locked eyes before it kills (tests shrink this)
let stareT = 0;   // builds while a live subject is reportable on your feed
let deathT = 0;   // >0 while the stare-kill cinematic plays
let deathPhase = ''; // 'freeze' | 'burst' | 'settle'
let caughtT = 0;     // >0 while the caught jumpscare lunge is on screen
let heartT = 0;   // heartbeat timer
let warnedStare = false;

// The scare is a three-beat sequence: a held-breath freeze, a violent burst,
// then a decaying settle. Total ~1.55s.
const DEATH_FREEZE = 0.26;
const DEATH_BURST = 0.82;
const DEATH_SETTLE = 0.47;
const DEATH_TOTAL = DEATH_FREEZE + DEATH_BURST + DEATH_SETTLE;

function updateStare(dt) {
  if (deathT > 0) return; // the kill cinematic owns the frame
  const onFeed = monitor.open && monster.present && monster.stationIndex === monitor.state.index;
  if (onFeed && deathT <= 0) {
    const res = monitor.inspect();
    if (res.visible) {
      stareT += dt;
      const dread = Math.min(1, stareT / debugTuning.stareLimit);
      monster.faceCam = monitor.station.camera;
      monster.setDread(dread);
      monitor.setDread(dread);
      // heartbeat quickens as it locks on
      heartT -= dt;
      if (heartT <= 0) {
        audio.heartbeat(0.2 + dread * 0.3);
        heartT = 1.1 - dread * 0.75;
      }
      if (dread > 0.45) {
        document.getElementById('stare-warn')?.classList.remove('hidden');
        if (!warnedStare) {
          warnedStare = true;
          audio.riser();
          hand.flinch(1); // your hands come up when it locks eyes
          showToast('👁 IT SEES YOU — REPORT IT (R) OR LOOK AWAY', 'bad');
        }
      }
      if (stareT >= debugTuning.stareLimit) startStareKill();
      return;
    }
  }
  // not looking at it: the lock loosens
  stareT = Math.max(0, stareT - dt * 0.6);
  monster.faceCam = null;
  if (stareT === 0) {
    monster.setDread(0);
    monitor.setDread(0);
    warnedStare = false;
    document.getElementById('stare-warn')?.classList.add('hidden');
  } else {
    const dread = Math.min(1, stareT / debugTuning.stareLimit);
    monster.setDread(dread);
    monitor.setDread(dread);
  }
}

function startStareKill() {
  deathT = DEATH_TOTAL;
  deathPhase = 'freeze';
  monitor.state.zoomIx = monitor.ZOOMS.length - 1;
  // The freeze is quiet and wrong: a stab, then a rising drone under it.
  audio.sting();
  audio.riser();
  audio.heartbeat(0.5);
}

/** Wipe every effect the scare layers on, so a retry starts clean. */
function clearScareFx() {
  deathPhase = '';
  caughtT = 0;
  const flashEl = document.getElementById('flash');
  if (flashEl) flashEl.style.opacity = '0';
  canvas.style.transform = '';
  canvas.style.filter = '';
}

function resetStare() {
  stareT = 0; deathT = 0; heartT = 0; warnedStare = false;
  clearScareFx();
  monster.faceCam = null;
  monster.setDread(0);
  monitor.setDread(0);
  canvas.style.transform = '';
  document.getElementById('stare-warn')?.classList.add('hidden');
}

/** Remote-room lights are alive: hallway tube flickers, boiler breathes. */
function flickerLights() {
  const hall = stations[1];
  if (hall?.light) {
    // rare 2% dropout on the failing tube in the hallway
    const drop = Math.random() < 0.02 ? 0.45 + Math.random() * 0.35 : 1;
    const target = hall.lightBase * drop * (0.94 + Math.random() * 0.06);
    hall.light.intensity += (target - hall.light.intensity) * 0.35;
    if (hall.fill) hall.fill.intensity = hall.lightBase * 0.35 * drop;
  }
  const boiler = stations[4];
  if (boiler?.light) {
    boiler.light.intensity = boiler.lightBase * (0.92 + Math.sin(performance.now() / 700) * 0.08);
  }
  // A faint lamp hum-breath on the remaining stations so nothing sits static.
  for (const st of stations) {
    if (!st.light || st === hall || st === boiler) continue;
    st.light.intensity = st.lightBase * (0.97 + Math.sin(performance.now() / 1500 + st.idx) * 0.03);
  }
}
const DOOR_SPOT = new THREE.Vector3(3.2, 0, -3.3);
let breathStop = null;
let huntBangT = 0; // door impacts while it creeps in
let rainSurge = 0; // storm rain hammers the windows, then settles

function startHunt() {
  monster.beginHunt(DOOR_SPOT);
  gameState.huntsFaced += 1;
  hand.flinch(1);
  hand.setClench(1); // you grab the desk edge
  if (monitor.open) standUp(); // yanked out of the chair
  audio.doorCreak();
  breathStop = audio.startBreath();
  monitor.staticBurst(1.2); // every feed dies as it leaves the rooms
  showToast('⚠️ SOMETHING IS OPENING THE DOOR', 'bad');
  document.getElementById('door-warn')?.classList.remove('hidden');
  // red alert: the room itself bleeds, and your beam starts to fail
  if (!anomalies.active.some((a) => a.def.tag === 'lamp-flicker')) {
    refs.lampLight.color.setHex(0xff2a1a);
    refs.bulb.material.color.setHex(0xff2a1a);
  }
  flashlight.fear = 1;
  huntBangT = 0.8; // first impact a second after the creak
}

function resolveHunt() {
  document.getElementById('door-warn')?.classList.add('hidden');
  if (player.mode === 'hide') {
    stopHunt();
    gameState.huntsSurvived += 1;
    audio.slam();
    showToast('…it slammed the door and left. You survived.', 'good');
  } else {
    // Caught: it rushes the lens. White-out on top of the lunge so the last
    // frames are the face, not a prop standing still in the room.
    monster.beginScare(camera);
    audio.scream();
    audio.bang();
    audio.heartbeat(0.8);
    const fl = document.getElementById('flash');
    if (fl) fl.style.opacity = '0.9';
    caughtT = 0.0001; // positive elapsed time drives the shake while it closes in (see the loop)
  }
}

function stopHunt() {
  monster.reset();
  refs.doorPivot.rotation.y = 0;
  hand.setClench(0); // you let go of the desk
  document.getElementById('door-warn')?.classList.add('hidden');
  if (breathStop) { breathStop(); breathStop = null; }
  flashlight.fear = 0;
  // restore warm lamplight unless a blackout is running (it owns the lamp)
  if (!scare.lightsOutActive && !anomalies.active.some((a) => a.def.tag === 'lamp-flicker')) {
    refs.lampLight.intensity = 5.5;
    refs.lampLight.color.setHex(0xffd9a0);
    refs.bulb.material.color.setHex(0xffe9a8);
  }
}

/** Full lamp reset for shift starts / game over. */
function resetOfficeLights() {
  flashlight.fear = 0;
  refs.lampLight.intensity = 5.5;
  refs.lampLight.color.setHex(0xffd9a0);
  refs.bulb.material.color.setHex(0xffe9a8);
}

const monsterHooks = {
  onHuntStart: () => startHunt(),
  onHuntResolve: () => resolveHunt(),
  onHuntWarning: () => {
    audio.knock();
    audio.approach();
    showToast('🚪 SOMETHING IS RATTLING THE DOOR…', 'bad');
  },
  onCaught: () => endGame(false, 'It found you. Never turn your back on the door.'),
};

// --- Start / restart / night flow ---
let pendingNight = 1;

function showCard(night) {
  pendingNight = night;
  audio.unlock(); audio.click();
  showNightCard(night, gameState.bestNight, nightConfig(night));
}

document.getElementById('start-btn').addEventListener('click', () => { gameState.mp = false; showCard(1); });
document.getElementById('start-mp-btn')?.addEventListener('click', () => { gameState.mp = true; showCard(1); });
document.getElementById('begin-btn').addEventListener('click', () => startShift(pendingNight));
document.getElementById('retry-btn').addEventListener('click', () => startShift(gameState.night));
document.getElementById('again-btn').addEventListener('click', () => showCard(gameState.night + 1));
document.getElementById('resume-btn').addEventListener('click', () => resumeGame());
document.getElementById('restart-btn').addEventListener('click', () => startShift(gameState.night));

function startShift(night) {
  audio.unlock(); audio.click();
  audio.resume();
  audio.startAmbience();
  anomalies.reset();
  resetGame(night);
  saveBestNight(night);
  gameState.bestNight = Math.max(gameState.bestNight, night);
  reportCooldown = 0;
  player.reset();
  hand.sync();
  hand.setTremor(0);
  hand.setClench(0);
  hand.setVisible(true);
  hand.setTorch(flashlight.on);
  flashlight.on = true; flashlight.battery = 100;
  // monster / monitor layer reset
  monster.reset();
  monster.stalker = false;
  refs.doorPivot.rotation.y = 0;
  if (player.POSES && player.POSES.hide) player.POSES.hide.pos.set(-1.2, 0.52, -2.02);
  monitor.close();
  stopHunt();
  scare.reset();
  resetOfficeLights();
  resetStare();
  unhide();
  document.getElementById('pause-screen').classList.add('hidden');
  hideScreens();
  showToast(`Night ${night} started. Watch the room and the cameras. (E = monitor)`, 'info');
  // brief intro fade
  try {
    const intro = document.createElement('div');
    const lines = 'YOU WOKE UP... YOU HEARD A SOUND... OF THINGS MOVING... YOU TRIED TO SLEEP... YOU CANT... BUT... YOUR HOME... ALONE... TRY TO INVESTIGATE... WHAT IS HAPPENING...';
    intro.innerHTML = lines.split('...').map(s => s ? `<div class="intro-line">${s.trim()}</div>` : '').join('');
    intro.className = 'intro-screen';
    intro.style.cssText = 'position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:20px;color:#fff;background:#000;z-index:40;font-size:clamp(10px,1.8vw,16px);letter-spacing:3px;text-transform:uppercase;pointer-events:none;cursor:pointer;';
    document.body.appendChild(intro);
    const els = intro.querySelectorAll('.intro-line');
    let current = 0;
    const showLine = (i) => {
      if (i >= els.length) return;
      const el = els[i];
      el.style.opacity = '1';
      el.style.transform = 'translateY(0)';
    };
    els.forEach((el, i) => {
      el.style.opacity = '0';
      el.style.transform = 'translateY(10px)';
      el.style.transition = 'opacity 1.2s ease, transform 1.2s ease';
    });
    const timers = [];
    for (let i = 0; i < els.length; i++) {
      timers.push(setTimeout(() => { current = i + 1; showLine(i); }, 300 + i * 1000));
    }
    const total = 300 + els.length * 1000 + 500;
    timers.push(setTimeout(() => intro.style.opacity = '0', total));
    timers.push(setTimeout(() => intro.remove(), total + 2500));
    intro.addEventListener('click', (e) => {
      // skip to next line or finish
      if (current < els.length) {
        for (const t of timers) clearTimeout(t);
        for (let i = current; i < els.length; i++) {
          showLine(i);
          current = els.length;
        }
        setTimeout(() => { intro.style.opacity = '0'; setTimeout(() => intro.remove(), 800); }, 400);
      } else {
        for (const t of timers) clearTimeout(t);
        intro.style.opacity = '0';
        setTimeout(() => intro.remove(), 800);
      }
    }, { once: true });
  } catch (e) {}
  // pointer lock for FPS feel
  lockPointer();
}

function endGame(won, reason = null) {
  audio.stopAmbience();
  resetStare();
  scare.reset();
  resetOfficeLights();
  if (breathStop) { breathStop(); breathStop = null; }
  if (monitor.open) monitor.close();
  unhide();
  document.getElementById('pause-screen').classList.add('hidden');
  if (won) {
    gameState.phase = GamePhase.WIN;
    document.getElementById('win-night').textContent =
      `6:00 AM. Sunny survived Night ${gameState.night}.`;
    document.getElementById('win-stats').textContent =
      `Anomalies logged: ${gameState.reports} · Subjects logged: ${gameState.monstersLogged} · Hunts survived: ${gameState.huntsSurvived} · Missed: ${gameState.missed} · Best: Night ${gameState.bestNight}`;
    showScreen('win-screen');
    audio.win();
  } else {
    gameState.phase = GamePhase.GAMEOVER;
    document.getElementById('lose-stats').textContent =
      `Night ${gameState.night} · Anomalies logged: ${gameState.reports} · Subjects logged: ${gameState.monstersLogged} · Missed: ${gameState.missed} · Time: ${(gameState.elapsed | 0)}s`;
    document.getElementById('lose-reason').textContent =
      reason ?? 'The anomalies got you…';
    showScreen('gameover-screen');
    audio.lose();
  }
  document.exitPointerLock?.();
}

// --- Main loop ---
const clock = new THREE.Clock();
let tickAcc = 0;

function loop() {
  requestAnimationFrame(loop);
  const dt = Math.min(clock.getDelta(), 0.05);

  if (gameState.phase === GamePhase.PAUSED) {
    // Frozen frame behind the pause menu; timers and input stay put.
    quality.render();
    return;
  }

  if (gameState.phase === GamePhase.PLAYING) {
    gameState.elapsed += dt;
    player.update(dt, { refs });
    flashlight.update(dt);
    hand.update({
      dt,
      yaw: player.yaw,
      pitch: player.pitch,
      walking: player.speedNow > 0.15,
      mode: player.mode,
      fear: flashlight.fear,
      dread: Math.max(monitor.dread, monster.dread),
      hunt: monster.hunting,
      dead: deathT > 0,
      torchUp: flashlight.on && player.mode === 'walk',
    });
    hand.setTremor(
      (deathT > 0 ? 1 : 0) * 0.9
      + (monster.hunting ? 0.45 : 0)
      + (monitor.dread > 0.3 ? 0.25 : 0)
      + (scare.lightsOutActive ? 0.15 : 0)
    );
    hand.setVisible(!monitor.open);
    reportCooldown = Math.max(0, reportCooldown - dt);
    document.getElementById('crosshair')?.classList.toggle('cooling', reportCooldown > 0);

    // anomaly spawning follows the current night's difficulty
    const cfg = nightConfig(gameState.night);
    gameState.spawnTimer += dt;
    if (gameState.spawnTimer >= gameState.nextSpawnIn && anomalies.active.length < cfg.maxActive) {
      gameState.spawnTimer = 0;
      gameState.nextSpawnIn = cfg.spawnMin + Math.random() * (cfg.spawnMax - cfg.spawnMin);
      const inst = anomalies.trySpawn(cfg.subtleChance, cfg.durationScale);
      if (inst) showToast(`⚠️ Something feels off… (${anomalies.active.length} active)`, 'warn');
    }

    // subject-on-cameras scheduling
    gameState.monsterTimer += dt;
    if (gameState.monsterTimer >= gameState.nextMonsterIn && monster.state === MonsterState.IDLE) {
      gameState.monsterTimer = 0;
      gameState.nextMonsterIn = cfg.monsterSpawnMin + Math.random() * (cfg.monsterSpawnMax - cfg.monsterSpawnMin);
      const roomIx = 1 + Math.floor(Math.random() * (stations.length - 1));
      monster.spawn(roomIx, stations[roomIx].patrol, cfg.monsterDwell);
      showToast(`⚠️ MOTION ON THE CAMERAS — SIT AT THE MONITOR (E)`, 'warn');
      audio.camSwitch();
    }
    monster.update(dt, monsterHooks);

    // hunt: the office door swings open while it creeps in
    if (monster.hunting) {
      const cur = refs.doorPivot.rotation.y;
      refs.doorPivot.rotation.y = cur + (-1.1 - cur) * Math.min(1, dt * 1.4);
      // it beats on the doorframe as it closes in
      huntBangT -= dt;
      if (huntBangT <= 0) { audio.bang(); huntBangT = 1.3; }
    }

    // lightning surge: rain hammers the windows for a stretch after each strike
    if (storm.intensity > 1 && rainSurge <= 0) {
      rainSurge = 10;
      audio.setRain(0.45);
    }
    if (rainSurge > 0) {
      rainSurge -= dt;
      if (rainSurge <= 0) audio.setRain(0.07);
    }

    // context prompt near the desk / door / breaker / lockers
    const promptEl = document.getElementById('prompt');
    if (promptEl && !gameState.powerFixing) {
      if (gameState.powerOut && !gameState.powerFixed && player.mode === 'walk' && Math.hypot(player.pos.x - 3.6, player.pos.z + 3.0) < 1.8) {
        promptEl.textContent = 'GO THROUGH THE DOOR → FIX WIRES IN THE POWER ROOM';
        promptEl.classList.remove('hidden');
    } else if (gameState.powerOut && player.mode === 'walk' && distToLocker() <= 1.5) {
      promptEl.textContent = 'H — HIDE IN LOCKER';
      promptEl.classList.remove('hidden');
    } else if (!monitor.open && player.mode === 'walk' && distToBed() <= 1.5) {
      promptEl.textContent = 'H — HIDE UNDER BED';
      promptEl.classList.remove('hidden');
    } else if (!monitor.open && player.mode === 'walk' && distToDesk() <= HIDE_RADIUS) {
        promptEl.textContent = 'E — USE MONITOR · H — HIDE UNDER DESK';
        promptEl.classList.remove('hidden');
      } else {
        promptEl.classList.add('hidden');
      }
    }

    monitor.update(dt);

    // ambient horror: glimpses, blackouts, whispers, lightning
    scare.update(dt, {
      cfg,
      lampBusy: anomalies.active.some((a) => a.def.tag === 'lamp-flicker'),
      seated: player.mode === 'desk',
    });
    camera.rotation.z += scare.consumeShudder(dt); // whisper shudder (roll resets every frame)

    // Night 2 power outage: leave the office through the door, fix wires in the power room
    if ((gameState.night >= 2) && !gameState.powerEventTriggered && gameState.elapsed>=90){
      gameState.powerEventTriggered=true;
      scare.lightsOut(9999);
      try{audio.powerDown();}catch(e){}
      gameState.powerOut=true;
      gameState.powerFixed=false;
      gameState.powerFixProgress=0;
      gameState.powerFixTarget=3.0;
      gameState.powerFixing=false;
      refs.doorPivot.rotation.y = -1.1; // door swings open: you can leave
      showToast("POWER OUT — Press E to go through the door. Fix the wires in the POWER ROOM. It hunts out there — hide (H).","bad");
    }
    if (gameState.powerOut && !gameState.powerFixed) {
      refs.doorPivot.rotation.y += (-1.1 - refs.doorPivot.rotation.y) * Math.min(1, dt * 2);
      if (refs.breakerLamp) refs.breakerLamp.material.color.setHex(Math.sin(performance.now() / 150) > 0 ? 0xff2222 : 0x440000);
      const bp = refs.breakerPos || { x: 5.5, z: -13.2 };
      const nearBreaker = Math.hypot(camera.position.x - bp.x, camera.position.z - bp.z) < 1.6;
      if (nearBreaker && !monitor.open && player.mode === 'walk') {
        gameState.powerFixProgress += dt;
        gameState.powerFixing = true;
        const pEl = document.getElementById('prompt');
        if (pEl) { pEl.textContent = 'FIXING WIRES… stay by the breaker'; pEl.classList.remove('hidden'); }
        if (gameState.powerFixProgress >= gameState.powerFixTarget) {
          gameState.powerFixed = true; gameState.powerOut = false; gameState.powerFixing = false;
          scare.restoreLamp(); try { audio.powerUp(); } catch (e) {}
          if (monster.stalker) { monster.fig.visible = false; monster.stalker = false; }
          showToast('Power restored. Get back to the office.', 'good');
        }
      } else { gameState.powerFixing = false; }
      // hallway stalker while the power is out: it roams the power room, kills if it touches you
      const outside = player.pos.z < -4.2;
      if (outside && !gameState.powerFixed && player.mode !== 'hide' && !monster.hunting && !monster.scaring && deathT <= 0) {
        if (!monster.stalker) {
          monster.stalker = true;
          monster.fig.visible = true;
          monster.fig.position.set(3.5, 0, -10.5);
          try { audio.sting(); } catch (e) {}
          showToast('IT IS OUT HERE WITH YOU — HIDE (H)', 'bad');
        }
      }
      if (monster.stalker && !gameState.powerFixed) {
        if (player.mode === 'hide') {
          // lost you: drift back toward the corridor mouth
          monster.fig.position.x += (3.6 - monster.fig.position.x) * Math.min(1, dt * 0.4);
          monster.fig.position.z += (-10.0 - monster.fig.position.z) * Math.min(1, dt * 0.4);
        } else {
          const dx = player.pos.x - monster.fig.position.x, dz = player.pos.z - monster.fig.position.z;
          const d = Math.hypot(dx, dz) || 1;
          const sp = 1.35;
          monster.fig.position.x += (dx / d) * Math.min(sp * dt, d);
          monster.fig.position.z += (dz / d) * Math.min(sp * dt, d);
          monster.fig.rotation.y = Math.atan2(dx, dz);
          monster.fig.position.y = Math.abs(Math.sin(performance.now() / 300)) * 0.04;
          if (d < 0.9) {
            monster.stalker = false;
            monster.beginScare(camera);
            audio.scream(); audio.bang();
            const fl = document.getElementById('flash');
            if (fl) fl.style.opacity = '0.9';
            caughtT = 0.0001;
          }
        }
      }
    }
    // The stare: keeping a live subject on your current feed lets it lock
    // eyes. It turns to the lens, the feed bleeds, the heart pounds — and
    // after STARE_LIMIT seconds it kills you. Look away or report it.
    updateStare(dt);

    // death cinematic (stare kill): slam to max zoom on its face, then game over
    if (deathT > 0) {
      deathT -= dt;
      monitor.setDread(1);
      monster.setDread(1);
      const fig = monster.fig;
      const ndc = fig.position.clone().project(monitor.station.camera);
      monitor.state.zoomIx = monitor.ZOOMS.length - 1;
      monitor.centerOn(ndc.x, ndc.y);
      monitor.refreshDom();

      const flashEl = document.getElementById('flash');
      const elapsed = DEATH_TOTAL - deathT;

      // One-shot the moment the freeze breaks open into the burst.
      if (deathPhase === 'freeze' && elapsed >= DEATH_FREEZE) {
        deathPhase = 'burst';
        audio.scream();
        audio.bang();
        audio.heartbeat(0.75);
        if (flashEl) flashEl.style.opacity = '0.92';
      }

      // ---- Beat 1: freeze. Colour drains, the frame barely moves, the zoom
      // creeps in. Reads as the held breath before something awful.
      if (elapsed < DEATH_FREEZE) {
        const f = elapsed / DEATH_FREEZE;
        canvas.style.transform =
          `translate(${(Math.random() - 0.5) * 2}px, ${(Math.random() - 0.5) * 2}px)`;
        canvas.style.filter =
          `saturate(${(1 - f * 0.85).toFixed(2)}) contrast(${(1 + f * 0.5).toFixed(2)}) brightness(${(1 - f * 0.35).toFixed(2)})`;
        if (flashEl) flashEl.style.opacity = '0';

        // ---- Beat 2: burst. Violent shake, hue tearing and a stuttering
        // exposure while the feed slams to max zoom on the face.
      } else if (elapsed < DEATH_FREEZE + DEATH_BURST) {
        deathPhase = 'burst';
        const b = (elapsed - DEATH_FREEZE) / DEATH_BURST;
        const s = 26 * (1 - b * 0.55);
        const rot = (Math.random() - 0.5) * 2.4 * (1 - b * 0.6);
        canvas.style.transform =
          `translate(${(Math.random() - 0.5) * s}px, ${(Math.random() - 0.5) * s}px) rotate(${rot}deg)`;
        // strobe the exposure so the image stutters instead of pulsing smoothly
        const dark = Math.random() < 0.35;
        canvas.style.filter = dark
          ? 'saturate(0.25) contrast(1.9) brightness(0.4)'
          : `saturate(2.2) contrast(1.9) hue-rotate(${((Math.random() - 0.5) * 40).toFixed(0)}deg)`;
        if (flashEl) flashEl.style.opacity = String(Math.max(0, 0.9 * (1 - b * 3)));

        // ---- Beat 3: settle. Shake and colour bleed off, then you die.
      } else {
        const s2 = (elapsed - DEATH_FREEZE - DEATH_BURST) / DEATH_SETTLE;
        canvas.style.transform =
          `translate(${(Math.random() - 0.5) * 11 * (1 - s2)}px, ${(Math.random() - 0.5) * 11 * (1 - s2)}px)`;
        canvas.style.filter =
          `saturate(0.2) contrast(1.5) brightness(${(0.6 + 0.4 * (1 - s2)).toFixed(2)})`;
        if (flashEl) flashEl.style.opacity = '0';
      }

      if (deathT <= 0) {
        clearScareFx();
        endGame(false, 'It stared back. You should have looked away.');
      }
    }

    // Caught jumpscare: the shake and colour tear ramp as it closes on the lens.
    if (caughtT > 0 && deathT <= 0) {
      caughtT += dt;
      const k = Math.min(1, caughtT / monster.scareDur);
      const s = 12 + 20 * k;
      const rot = (Math.random() - 0.5) * (1 + 3 * k);
      canvas.style.transform =
        `translate(${(Math.random() - 0.5) * s}px, ${(Math.random() - 0.5) * s}px) rotate(${rot}deg)`;
      canvas.style.filter = Math.random() < 0.3
        ? 'saturate(0.3) contrast(1.8) brightness(0.45)'
        : `saturate(2) contrast(1.6) hue-rotate(${((Math.random() - 0.5) * 30).toFixed(0)}deg)`;
      const cf = document.getElementById('flash');
      if (cf) cf.style.opacity = String(Math.max(0, 0.9 * (1 - k * 4)));
    }

    // remote-room lights breathe: the hallway tube flickers, the boiler pulses
    flickerLights();

    // dread vignette: the screen bleeds as it locks on / hunts / kills
    const dreadEl = document.getElementById('dread');
    if (dreadEl) {
      const target = deathT > 0 ? 1 : monster.hunting ? 0.55 : monitor.open ? monitor.dread : 0;
      const cur = parseFloat(dreadEl.dataset.v || '0');
      if (Math.abs(target - cur) > 0.03) {
        dreadEl.dataset.v = String(target);
        dreadEl.style.opacity = String(target);
      }
    }
    // heartbeat while it is inside the office with you
    if (monster.hunting) {
      heartT -= dt;
      if (heartT <= 0) { audio.heartbeat(0.35); heartT = 0.7; }
    }

    // anomaly expiry => missed (no strikes anymore; the subject is the threat)
    const expired = anomalies.update(dt);
    for (const e of expired) {
      gameState.missed += 1;
      audio.buzz();
      showToast(`👁 MISSED: ${e.def.label} (it got away)`, 'bad');
    }

    // win condition
    if (gameState.elapsed >= gameState.shiftLength) endGame(true);

    // hourly tick sound
    tickAcc += dt;
    if (tickAcc > 50) { tickAcc = 0; audio.tick(); }

    updateHUD(flashlight.battery, anomalies.active.length);
  } else {
    // idle camera sway on title screen
    const t = performance.now() / 1000;
    camera.position.set(Math.sin(t * 0.2) * 1.5, 1.6, 2.8);
    camera.lookAt(0, 1.2, -3);
    flashlight.update(0.016);
  }

  quality.render();
  // First-person hand, drawn last so it's never clipped by world geometry and
  // never picks up the room's fog. Hidden while seated (you'd be looking at
  // the monitor, not your hand).
  hand.render(renderer, camera.aspect);
  if (monitor.open) monitor.render(); // CCTV frame fullscreen over the office
  if (monster.scaring) { /* jumpscare renders the figure point-blank at the lens */ }
  // the dark breathes almost imperceptibly — the night feels alive
  renderer.toneMappingExposure = 1.45 + Math.sin(performance.now() / 2600) * 0.025;
  quality.update();
}

document.getElementById('title-best').textContent =
  gameState.bestNight > 1 ? `Highest night reached: ${gameState.bestNight}` : 'No nights survived yet. Good luck.';
showScreen('title-screen');

// Debug/testing handle (used by the automated playtest; harmless in production).
window.__game = {
  THREE, gameState, GamePhase, anomalies, flashlight, player, camera, scene, renderer, refs, composer, colliders, quality,
  stations, monster, monitor, MonsterState, DOOR_SPOT, scare, storm, audio, hand,
  reportAnomaly, reportCurrent, reportSubject, startShift, pauseGame, resumeGame,
  toggleMonitor, standUp, toggleHide, unhide, startHunt, resolveHunt, stopHunt, resetOfficeLights,
  debug: debugTuning,
  get stareT() { return stareT; },
  get deathT() { return deathT; },
  get reportCooldown() { return reportCooldown; },
};
updateHUD(100, 0);
loop();
